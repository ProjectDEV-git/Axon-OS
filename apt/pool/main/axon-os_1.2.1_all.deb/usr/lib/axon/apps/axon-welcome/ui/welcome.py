"""Axon OS Welcome App — WelcomeWindow (onboarding wizard)."""

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
import dbus
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import Adw, GLib, Gtk

# Shared GTK helpers live in apps/shared next to every app
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "shared"))
from axon_gtk_utils import fit_default_size, load_app_css

# services/ sits next to apps/ in the source tree and the .deb, and inside
# the app directory for install.sh
for _base in (Path(__file__).resolve().parents[3], Path(__file__).resolve().parents[2]):
    if (_base / "services").is_dir():
        sys.path.insert(0, str(_base / "services"))
        break
from i18n import _

# Insert axon-brain path so we can run hardware profiler
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "services" / "axon-brain"))
try:
    import hardware_profiler
except ImportError:
    hardware_profiler = None

# apps/axon-welcome/ holds windows_mode.py (also importable without GTK)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import windows_mode
from gaming_page import GamingPage
from gpu_drivers import detect_graphics

# Hash-pinned Ollama installer shipped in the image (see build/config/install-ollama.sh)
OLLAMA_INSTALLER = "/usr/lib/axon/ollama/install-ollama.sh"
OLLAMA_URL = "http://127.0.0.1:11434"

# ---------------------------------------------------------------------------
# Embedded CSS
# ---------------------------------------------------------------------------


def _add_class(widget: Gtk.Widget, css_class: str) -> None:
    widget.get_style_context().add_class(css_class)


def _remove_class(widget: Gtk.Widget, css_class: str) -> None:
    widget.get_style_context().remove_class(css_class)


def _scrollable(page: Gtk.Widget) -> Gtk.ScrolledWindow:
    """Let a page scroll vertically instead of forcing the window to be taller
    than small screens (e.g. 800x600 in VirtualBox safe graphics)."""
    scroller = Gtk.ScrolledWindow()
    scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroller.set_child(page)
    return scroller


class WelcomeWindow(Adw.Window):
    _PAGE_NAMES = ["welcome", "setup", "gaming", "preferences", "windows", "features", "ready"]  # noqa: RUF012

    def __init__(self, app: Adw.Application):
        super().__init__(application=app)

        # Initialize DBus GLib loop integration early
        DBusGMainLoop(set_as_default=True)
        self.bus = dbus.SessionBus()
        self.brain = None
        self._connect_brain()

        # Track model downloading state
        self._downloading_model = None

        # Run hardware profiling
        self._profile = {}
        self._models = []
        self._run_profiling()

        # Window properties
        self.set_title(_("Welcome to Axon OS"))
        fit_default_size(self, 640, 600)
        self.set_decorated(True)

        load_app_css(Path(__file__).with_name("welcome.css"), self.get_display())

        # Root layout
        root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        _add_class(root_box, "welcome-window")

        clamp = Adw.Clamp()
        clamp.set_maximum_size(560)
        clamp.set_vexpand(True)

        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
        self._stack.set_vexpand(True)

        # Page indicator
        self._dot_labels: list[Gtk.Label] = []
        indicator_row = self._build_indicator()

        # Build pages
        self._stack.add_named(_scrollable(self._build_page_welcome()), "welcome")
        self._stack.add_named(_scrollable(self._build_page_setup()), "setup")
        self._stack.add_named(_scrollable(self._build_page_gaming()), "gaming")
        self._stack.add_named(_scrollable(self._build_page_preferences()), "preferences")
        self._stack.add_named(_scrollable(self._build_page_windows()), "windows")
        self._stack.add_named(_scrollable(self._build_page_features()), "features")
        self._stack.add_named(_scrollable(self._build_page_ready()), "ready")

        inner_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        inner_box.append(self._stack)
        inner_box.append(indicator_row)

        clamp.set_child(inner_box)
        root_box.append(clamp)
        self.set_content(root_box)

        # Track current page index
        self._current_page = 0
        self._update_indicator()

        # Register D-Bus signal listener for model pulls
        self.bus.add_signal_receiver(
            self._on_pull_progress, signal_name="PullProgress", dbus_interface="org.axonos.Brain"
        )

        # Clean up signal receiver when window is destroyed
        self.connect("destroy", self._on_destroy)

    def _connect_brain(self) -> None:
        try:
            self.brain = self.bus.get_object("org.axonos.Brain", "/org/axonos/Brain")
        except Exception:
            self.brain = None

    def _on_destroy(self, _widget) -> None:
        """Remove D-Bus signal receivers to break reference cycles."""
        try:
            self.bus.remove_signal_receiver(
                self._on_pull_progress,
                signal_name="PullProgress",
                dbus_interface="org.axonos.Brain",
            )
        except Exception:
            pass

    def _run_profiling(self) -> None:
        if hardware_profiler:
            try:
                self._profile = hardware_profiler.profile_hardware()
                hw = self._profile.get("hardware", {})
                recs = self._profile.get("recommendations", {})
                self._hw_info_str = f"Hardware profile: {hw.get('ram_gb')}GB RAM | GPU: {hw.get('gpu_vendor')} ({hw.get('gpu_model')})"

                self._models = [
                    (
                        "Speed Model",
                        recs.get("speed", {}).get("model"),
                        recs.get("speed", {}).get("description"),
                    ),
                    (
                        "General Model",
                        recs.get("general", {}).get("model"),
                        recs.get("general", {}).get("description"),
                    ),
                    (
                        "Deep Task Model",
                        recs.get("deep", {}).get("model"),
                        recs.get("deep", {}).get("description"),
                    ),
                ]
                return
            except Exception:
                pass

        # Fallbacks if module is missing or fails
        self._hw_info_str = "Hardware profile: Generic System CPU"
        self._models = [
            ("Speed Model", "llama3.2:1b", "Llama 3.2 1B — fast command processing."),
            ("General Model", "llama3.2:3b", "Llama 3.2 3B — balanced conversation."),
            ("Deep Task Model", "llama3:8b", "Llama 3 8B — high reasoning, running on CPU RAM."),
        ]

    # ------------------------------------------------------------------
    # Page indicator
    # ------------------------------------------------------------------

    def _build_indicator(self) -> Gtk.Box:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        row.set_halign(Gtk.Align.CENTER)
        row.set_margin_bottom(16)
        row.set_margin_top(6)

        for _attempt in self._PAGE_NAMES:
            dot = Gtk.Label(label="●")
            _add_class(dot, "page-indicator-dot")
            dot.set_opacity(0.3)
            self._dot_labels.append(dot)
            row.append(dot)

        return row

    def _update_indicator(self) -> None:
        for i, dot in enumerate(self._dot_labels):
            # Current page: full opacity and the accent colour (CSS)
            current = i == self._current_page
            dot.set_opacity(1.0 if current else 0.3)
            if current:
                dot.add_css_class("page-indicator-dot-current")
            else:
                dot.remove_css_class("page-indicator-dot-current")

    def _go_to(self, page_name: str) -> None:
        idx = self._PAGE_NAMES.index(page_name)
        current_idx = self._current_page

        if idx > current_idx:
            self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
        else:
            self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_RIGHT)

        self._stack.set_visible_child_name(page_name)
        self._current_page = idx
        self._update_indicator()

    # ------------------------------------------------------------------
    # PAGE 1 — Welcome
    # ------------------------------------------------------------------

    def _build_page_welcome(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        page.set_halign(Gtk.Align.CENTER)
        page.set_valign(Gtk.Align.FILL)
        page.set_margin_top(40)
        page.set_margin_bottom(24)
        page.set_margin_start(40)
        page.set_margin_end(40)

        # Hero logo
        logo = Gtk.Label(label="⬡")
        _add_class(logo, "hero-logo")
        logo.set_margin_bottom(8)
        page.append(logo)

        title = Gtk.Label(label=_("Welcome to Axon OS"))
        _add_class(title, "hero-title")
        title.set_wrap(True)
        title.set_width_chars(18)
        title.set_justify(Gtk.Justification.CENTER)
        page.append(title)

        # Honest by default: cloud models are supported, so never promise
        # "local only"; the AI panel and Intent Bar show where each request runs
        subtitle = Gtk.Label(
            label=_(
                "Your AI-native desktop. AI runs on this computer unless you choose a cloud model."
            )
        )
        _add_class(subtitle, "hero-subtitle")
        subtitle.set_wrap(True)
        # A readable measure: without it the column shrinks to one word per line
        subtitle.set_width_chars(36)
        subtitle.set_max_width_chars(48)
        subtitle.set_justify(Gtk.Justification.CENTER)
        page.append(subtitle)

        # Spacer
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        # Get Started button
        btn = Gtk.Button(label=_("Get Started"))
        _add_class(btn, "nav-btn-next")
        btn.set_halign(Gtk.Align.CENTER)
        btn.connect("clicked", lambda _: self._go_to("setup"))
        page.append(btn)

        return page

    # ------------------------------------------------------------------
    # PAGE 2 — Setup (AI Model Downloader)
    # ------------------------------------------------------------------

    def _build_page_setup(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(24)
        page.set_margin_bottom(24)
        page.set_margin_start(32)
        page.set_margin_end(32)

        # Title
        title = Gtk.Label(label=_("Set Up Your AI"))
        _add_class(title, "page-title")
        title.set_halign(Gtk.Align.START)
        page.append(title)

        subtitle = Gtk.Label(label=_("Axon recommends local models customized for your hardware."))
        _add_class(subtitle, "page-subtitle")
        subtitle.set_halign(Gtk.Align.START)
        subtitle.set_wrap(True)
        page.append(subtitle)

        # Hardware Info Badge
        hw_lbl = Gtk.Label(label=self._hw_info_str)
        _add_class(hw_lbl, "hardware-badge")
        hw_lbl.set_halign(Gtk.Align.START)
        page.append(hw_lbl)

        # Model checkboxes group
        self._model_checks = []
        self._selected_model = self._models[1][1]  # Default to General Model
        first_check = None

        for tier, model_id, model_desc in self._models:
            outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
            _add_class(outer, "model-row")

            check = Gtk.CheckButton()
            if first_check is None:
                first_check = check
            else:
                check.set_group(first_check)

            if model_id == self._selected_model:
                check.set_active(True)

            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            inner.set_hexpand(True)

            tier_lbl = Gtk.Label()
            tier_lbl.set_markup(
                f"<b>{GLib.markup_escape_text(tier)}</b>: {GLib.markup_escape_text(model_id)}"
            )
            _add_class(tier_lbl, "model-name")
            tier_lbl.set_halign(Gtk.Align.START)
            inner.append(tier_lbl)

            desc_lbl = Gtk.Label(label=model_desc)
            _add_class(desc_lbl, "model-desc")
            desc_lbl.set_halign(Gtk.Align.START)
            desc_lbl.set_wrap(True)
            inner.append(desc_lbl)

            check.set_child(inner)
            captured_id = model_id

            def _on_toggled(btn, mid=captured_id):
                if btn.get_active():
                    self._selected_model = mid

            check.connect("toggled", _on_toggled)
            self._model_checks.append(check)
            outer.append(check)
            page.append(outer)

        # Pull button + progress area
        self._pull_btn = Gtk.Button(label=_("Download Recommended Model"))
        _add_class(self._pull_btn, "nav-btn-next")
        self._pull_btn.set_halign(Gtk.Align.CENTER)
        self._pull_btn.set_margin_top(8)
        self._pull_btn.connect("clicked", self._on_pull_clicked)
        page.append(self._pull_btn)

        self._progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self._progress_box.set_visible(False)
        self._progress_box.set_margin_top(6)

        self._pull_progress = Gtk.ProgressBar()
        self._progress_lbl = Gtk.Label(label=_("Downloading: 0%"))
        _add_class(self._progress_lbl, "model-desc")
        self._progress_lbl.set_halign(Gtk.Align.CENTER)

        self._progress_box.append(self._pull_progress)
        self._progress_box.append(self._progress_lbl)
        page.append(self._progress_box)

        # Spacer
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        # Navigation row
        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_halign(Gtk.Align.CENTER)

        back_btn = Gtk.Button(label=_("← Back"))
        _add_class(back_btn, "nav-btn-back")
        back_btn.connect("clicked", lambda _: self._go_to("welcome"))
        nav.append(back_btn)

        skip_btn = Gtk.Button(label=_("Skip"))
        _add_class(skip_btn, "nav-btn-back")
        skip_btn.connect("clicked", lambda _: self._go_to("gaming"))
        nav.append(skip_btn)

        continue_btn = Gtk.Button(label=_("Continue →"))
        _add_class(continue_btn, "nav-btn-next")
        continue_btn.connect("clicked", lambda _: self._go_to("gaming"))
        nav.append(continue_btn)

        page.append(nav)

        return page

    # ------------------------------------------------------------------
    # PAGE — Gaming setup (presets install in the background)
    # ------------------------------------------------------------------

    def _build_page_gaming(self) -> Gtk.Widget:
        return GamingPage(
            on_back=lambda: self._go_to("setup"),
            on_next=lambda: self._go_to("preferences"),
            detect=detect_graphics,
        )

    # ------------------------------------------------------------------
    # D-Bus Signal Handler
    # ------------------------------------------------------------------

    def _on_pull_progress(self, model_name, completed_bytes, total_bytes, status):
        # Filter signals for our download
        if not self._downloading_model or model_name != self._downloading_model:
            return

        GLib.idle_add(self._update_pull_progress, completed_bytes, total_bytes, status)

    def _update_pull_progress(self, completed, total, status):
        if total > 0:
            fraction = float(completed) / float(total)
            self._pull_progress.set_fraction(fraction)
            percentage = int(fraction * 100)
            completed_gb = completed / (1024 * 1024 * 1024)
            total_gb = total / (1024 * 1024 * 1024)
            self._progress_lbl.set_text(
                f"Downloading: {percentage}% ({completed_gb:.2f} / {total_gb:.2f} GB)"
            )
        else:
            self._pull_progress.pulse()
            self._progress_lbl.set_text(f"Status: {status}")

        if status == "success" or "verify" in status.lower():
            self._progress_box.set_visible(False)
            self._pull_btn.set_sensitive(True)
            self._pull_btn.set_label(_("✓ Model Ready"))
            self._downloading_model = None
        elif "error" in status.lower():
            self._progress_box.set_visible(False)
            self._pull_btn.set_sensitive(True)
            self._pull_btn.set_label(_("Retry Download"))
            self._downloading_model = None

    # ------------------------------------------------------------------
    # Pull model action
    # ------------------------------------------------------------------

    def _ensure_ollama(self) -> bool:
        """Make sure the Ollama runtime is installed and its API is up.

        Runs on a worker thread. Returns False after reporting an error.
        """

        def _status(text: str) -> None:
            GLib.idle_add(self._update_pull_progress, 0, 0, text)

        def _firstboot_running() -> bool:
            # "activating" covers the unit waiting to retry a failed download
            state = subprocess.run(
                ["systemctl", "is-active", "axon-ai-firstboot.service"],
                capture_output=True,
                text=True,
                check=False,
            ).stdout.strip()
            return state in ("active", "activating")

        # The installed system's first boot downloads Ollama in the background;
        # starting a second download would only slow both down.
        deadline = time.monotonic() + 45 * 60
        while shutil.which("ollama") is None and _firstboot_running():
            if time.monotonic() > deadline:
                break
            _status(_("Ollama is still being installed in the background..."))
            time.sleep(5)

        if shutil.which("ollama") is None:
            _status(_("Installing Ollama runtime (a few minutes)..."))
            try:
                subprocess.run(
                    ["pkexec", OLLAMA_INSTALLER],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=True,
                )
            except (OSError, subprocess.CalledProcessError):
                _status(_("error: Ollama install failed — check your internet connection"))
                return False

        _status(_("Starting Ollama..."))
        for _attempt in range(30):
            try:
                with urllib.request.urlopen(f"{OLLAMA_URL}/api/tags", timeout=2):  # nosec B310
                    return True
            except OSError:
                time.sleep(2)
        _status(_("error: Ollama did not start — try again in a moment"))
        return False

    def _on_pull_clicked(self, _btn: Gtk.Button) -> None:
        model = self._selected_model
        self._downloading_model = model
        self._pull_btn.set_sensitive(False)
        self._progress_box.set_visible(True)
        self._pull_progress.set_fraction(0.0)
        self._progress_lbl.set_text(_("Connecting to Axon Brain..."))

        # Fire D-Bus pull request
        def _trigger_dbus_pull():
            # No Ollama runtime yet: wait for the first-boot installer if it is
            # still running, otherwise install it now (asks for the admin
            # password). The model itself is then pulled as usual below.
            if not self._ensure_ollama():
                return

            if self.brain is None:
                try:
                    self._connect_brain()
                except Exception:
                    pass

            if self.brain is not None:
                try:
                    self.brain.PullModel(model)
                except Exception as e:
                    GLib.idle_add(self._update_pull_progress, 0, 0, f"Error: {e}")
            else:
                # Local command fallback if service is missing
                GLib.idle_add(
                    self._update_pull_progress,
                    0,
                    0,
                    "Brain service not available. Retrying via CLI...",
                )
                try:
                    subprocess.run(
                        ["ollama", "pull", model],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=True,
                    )
                    GLib.idle_add(self._update_pull_progress, 1, 1, "success")
                except Exception:
                    GLib.idle_add(self._update_pull_progress, 0, 0, "error")

        threading.Thread(target=_trigger_dbus_pull, daemon=True).start()

    # ------------------------------------------------------------------
    # PAGE 2.5 — Preferences
    # ------------------------------------------------------------------

    def _build_page_preferences(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        page.set_margin_top(24)
        page.set_margin_bottom(24)
        page.set_margin_start(32)
        page.set_margin_end(32)

        # Title
        title = Gtk.Label(label=_("Preferences & Privacy"))
        _add_class(title, "page-title")
        title.set_halign(Gtk.Align.START)
        page.append(title)

        subtitle = Gtk.Label(label=_("Customize your default shell and AI context signals."))
        _add_class(subtitle, "page-subtitle")
        subtitle.set_halign(Gtk.Align.START)
        subtitle.set_wrap(True)
        page.append(subtitle)

        # Shell Selection Frame
        shell_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        shell_lbl = Gtk.Label(label=_("Preferred terminal shell"))
        shell_lbl.set_halign(Gtk.Align.START)
        _add_class(shell_lbl, "model-name")
        shell_box.append(shell_lbl)

        # List shells
        shells = [
            ("Bash", "/bin/bash", True),
            ("Zsh", "/usr/bin/zsh", shutil.which("zsh") is not None),
            ("Fish", "/usr/bin/fish", shutil.which("fish") is not None),
        ]

        self.selected_shell = "/bin/bash"
        config_path = Path.home() / ".config" / "axon-os" / "shell.conf"
        if config_path.exists():
            try:
                self.selected_shell = config_path.read_text().strip()
            except Exception:
                pass

        first_radio = None
        for name, path, installed in shells:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            _add_class(row, "model-row")
            if not installed:
                row.set_opacity(0.5)

            radio = Gtk.CheckButton()
            if first_radio is None:
                first_radio = radio
            else:
                radio.set_group(first_radio)

            radio.set_sensitive(installed)
            if path == self.selected_shell and installed:
                radio.set_active(True)
            elif name == "Bash" and not first_radio.get_active():
                radio.set_active(True)

            lbl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            name_lbl = Gtk.Label()
            name_lbl.set_markup(f"<b>{name}</b> ({path})")
            name_lbl.set_halign(Gtk.Align.START)
            lbl_box.append(name_lbl)

            if not installed:
                status_lbl = Gtk.Label(
                    label="Not installed — run 'sudo apt install " + name.lower() + "' to enable"
                )
                _add_class(status_lbl, "model-desc")
                status_lbl.set_halign(Gtk.Align.START)
                lbl_box.append(status_lbl)

            radio.set_child(lbl_box)

            def _on_shell_toggled(btn, p=path):
                if btn.get_active():
                    self.selected_shell = p
                    self._save_preferences()

            radio.connect("toggled", _on_shell_toggled)
            row.append(radio)
            shell_box.append(row)

        page.append(shell_box)

        # Context Privacy Options Frame
        privacy_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        privacy_lbl = Gtk.Label(label=_("AI Context Settings:"))
        privacy_lbl.set_halign(Gtk.Align.START)
        _add_class(privacy_lbl, "model-name")
        privacy_box.append(privacy_lbl)

        # Load current context config
        self.context_config = {
            "track_clipboard": True,
            "track_terminal_history": True,
            "track_open_files": True,
        }
        ctx_config_path = Path.home() / ".config" / "axon-os" / "context.json"
        if ctx_config_path.exists():
            try:
                with open(ctx_config_path) as f:
                    self.context_config.update(json.load(f))
            except Exception:
                pass

        # Clipboard switch
        clip_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        _add_class(clip_row, "model-row")
        clip_lbl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        clip_lbl_box.set_hexpand(True)
        clip_t = Gtk.Label(label=_("Clipboard Tracking"))
        clip_t.set_halign(Gtk.Align.START)
        _add_class(clip_t, "model-name")
        clip_d = Gtk.Label(label=_("Provide recent copy-paste text to the AI context."))
        clip_d.set_halign(Gtk.Align.START)
        _add_class(clip_d, "model-desc")
        clip_lbl_box.append(clip_t)
        clip_lbl_box.append(clip_d)
        clip_row.append(clip_lbl_box)

        self.clip_switch = Gtk.Switch()
        self.clip_switch.set_active(self.context_config["track_clipboard"])
        self.clip_switch.set_valign(Gtk.Align.CENTER)
        self.clip_switch.connect(
            "state-set", lambda sw, st: self._on_privacy_toggled("track_clipboard", st)
        )
        clip_row.append(self.clip_switch)
        privacy_box.append(clip_row)

        # Terminal History switch
        term_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        _add_class(term_row, "model-row")
        term_lbl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        term_lbl_box.set_hexpand(True)
        term_t = Gtk.Label(label=_("Terminal History Tracking"))
        term_t.set_halign(Gtk.Align.START)
        _add_class(term_t, "model-name")
        term_d = Gtk.Label(label=_("Provide recent bash/zsh/fish commands to the AI context."))
        term_d.set_halign(Gtk.Align.START)
        _add_class(term_d, "model-desc")
        term_lbl_box.append(term_t)
        term_lbl_box.append(term_d)
        term_row.append(term_lbl_box)

        self.term_switch = Gtk.Switch()
        self.term_switch.set_active(self.context_config["track_terminal_history"])
        self.term_switch.set_valign(Gtk.Align.CENTER)
        self.term_switch.connect(
            "state-set", lambda sw, st: self._on_privacy_toggled("track_terminal_history", st)
        )
        term_row.append(self.term_switch)
        privacy_box.append(term_row)

        # Open Files switch
        files_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        _add_class(files_row, "model-row")
        files_lbl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        files_lbl_box.set_hexpand(True)
        files_t = Gtk.Label(label=_("Editor Files Tracking"))
        files_t.set_halign(Gtk.Align.START)
        _add_class(files_t, "model-name")
        files_d = Gtk.Label(
            label=_("Provide open file names from editors (VSCode, Vim, nano) to the AI.")
        )
        files_d.set_halign(Gtk.Align.START)
        _add_class(files_d, "model-desc")
        files_lbl_box.append(files_t)
        files_lbl_box.append(files_d)
        files_row.append(files_lbl_box)

        self.files_switch = Gtk.Switch()
        self.files_switch.set_active(self.context_config["track_open_files"])
        self.files_switch.set_valign(Gtk.Align.CENTER)
        self.files_switch.connect(
            "state-set", lambda sw, st: self._on_privacy_toggled("track_open_files", st)
        )
        files_row.append(self.files_switch)
        privacy_box.append(files_row)

        page.append(privacy_box)

        # Spacer
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        # Navigation row
        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_halign(Gtk.Align.CENTER)

        back_btn = Gtk.Button(label=_("← Back"))
        _add_class(back_btn, "nav-btn-back")
        back_btn.connect("clicked", lambda _: self._go_to("gaming"))
        nav.append(back_btn)

        continue_btn = Gtk.Button(label=_("Continue →"))
        _add_class(continue_btn, "nav-btn-next")
        continue_btn.connect("clicked", lambda _: self._go_to("windows"))
        nav.append(continue_btn)

        page.append(nav)

        return page

    def _on_privacy_toggled(self, key, state):
        self.context_config[key] = state
        self._save_preferences()
        return False

    def _save_preferences(self):
        config_dir = Path.home() / ".config" / "axon-os"
        config_dir.mkdir(parents=True, exist_ok=True)
        try:
            with open(config_dir / "shell.conf", "w") as f:
                f.write(self.selected_shell)
        except Exception:
            pass
        try:
            with open(config_dir / "context.json", "w") as f:
                json.dump(self.context_config, f, indent=2)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # PAGE — Windows programs (APEX-WIN)
    # ------------------------------------------------------------------

    # (mode, title, description)
    _WINDOWS_CHOICES = (
        (
            "apex",
            "Axon APEX — full access (Recommended)",
            "Double-click any .exe or .msi and it runs with Wine like a normal app, "
            "with your files, network, GPU and controllers. No sandbox.",
        ),
        (
            "sandboxed",
            "Axon APEX — sandboxed",
            "Programs run in an isolated sandbox with their own home folder. Safer for "
            "downloads you don't trust; some games and installers won't work.",
        ),
        (
            "off",
            "Off",
            "Windows programs don't run. You can turn this on again here at any time.",
        ),
    )

    def _build_page_windows(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        page.set_margin_top(24)
        page.set_margin_bottom(24)
        page.set_margin_start(32)
        page.set_margin_end(32)

        title = Gtk.Label(label=_("Windows Programs"))
        _add_class(title, "page-title")
        title.set_halign(Gtk.Align.START)
        page.append(title)

        subtitle = Gtk.Label(
            label=_("Choose how Axon APEX opens Windows programs (.exe and .msi files).")
        )
        _add_class(subtitle, "page-subtitle")
        subtitle.set_halign(Gtk.Align.START)
        subtitle.set_wrap(True)
        page.append(subtitle)

        self.windows_mode = windows_mode.load_mode()
        choices_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self._windows_radios: dict[str, Gtk.CheckButton] = {}
        first_radio = None
        for mode, label, desc in self._WINDOWS_CHOICES:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            _add_class(row, "model-row")

            radio = Gtk.CheckButton()
            if first_radio is None:
                first_radio = radio
            else:
                radio.set_group(first_radio)

            lbl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name_lbl = Gtk.Label(label=label)
            _add_class(name_lbl, "model-name")
            name_lbl.set_halign(Gtk.Align.START)
            name_lbl.set_wrap(True)
            lbl_box.append(name_lbl)
            desc_lbl = Gtk.Label(label=desc)
            _add_class(desc_lbl, "model-desc")
            desc_lbl.set_halign(Gtk.Align.START)
            desc_lbl.set_wrap(True)
            desc_lbl.set_xalign(0)
            lbl_box.append(desc_lbl)
            radio.set_child(lbl_box)

            radio.set_active(mode == self.windows_mode)
            radio.connect("toggled", self._on_windows_mode_toggled, mode)
            self._windows_radios[mode] = radio
            row.append(radio)
            choices_box.append(row)
        page.append(choices_box)

        self._windows_status = Gtk.Label()
        _add_class(self._windows_status, "model-desc")
        self._windows_status.set_halign(Gtk.Align.START)
        self._windows_status.set_wrap(True)
        self._windows_status.set_xalign(0)
        if not windows_mode.apex_installed():
            self._windows_status.set_label(
                _(
                    "Axon APEX isn't installed on this system yet, so this choice applies once it is."
                )
            )
        page.append(self._windows_status)

        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_halign(Gtk.Align.CENTER)

        back_btn = Gtk.Button(label=_("← Back"))
        _add_class(back_btn, "nav-btn-back")
        back_btn.connect("clicked", lambda _: self._go_to("preferences"))
        nav.append(back_btn)

        continue_btn = Gtk.Button(label=_("Continue →"))
        _add_class(continue_btn, "nav-btn-next")
        continue_btn.connect("clicked", lambda _: self._go_to("features"))
        nav.append(continue_btn)

        page.append(nav)
        return page

    def _on_windows_mode_toggled(self, btn: Gtk.CheckButton, mode: str) -> None:
        if not btn.get_active():
            return
        try:
            windows_mode.save_mode(mode)
        except OSError as exc:
            self._windows_status.set_label(f"Could not save your choice: {exc}")
            return
        self.windows_mode = mode

    # ------------------------------------------------------------------
    # PAGE — Features
    # ------------------------------------------------------------------

    def _build_page_features(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        page.set_margin_top(32)
        page.set_margin_bottom(24)
        page.set_margin_start(32)
        page.set_margin_end(32)

        title = Gtk.Label(label=_("What Axon Can Do"))
        _add_class(title, "page-title")
        title.set_halign(Gtk.Align.START)
        page.append(title)

        grid = Gtk.Grid()
        grid.set_column_spacing(12)
        grid.set_row_spacing(12)
        grid.set_margin_top(8)

        feature_data = [
            (
                "axon-intent-bar-symbolic",
                _("Intent Bar"),
                _("Press Super+Space. Ask anything in natural language."),
            ),
            (
                "axon-ai-panel-symbolic",
                _("AI Panel"),
                _("Press Super+A. Your assistant, with your conversations kept."),
            ),
            (
                "view-grid-symbolic",
                _("Spaces"),
                _("Super+1–9. A named workspace for each project."),
            ),
            (
                "security-high-symbolic",
                _("You choose where AI runs"),
                _("Local models by default. Axon says when a request would leave this computer."),
            ),
        ]

        positions = [(0, 0), (1, 0), (0, 1), (1, 1)]

        for (icon, feat_title, feat_desc), (col, row) in zip(feature_data, positions, strict=False):
            card = self._build_feature_card(icon, feat_title, feat_desc)
            grid.attach(card, col, row, 1, 1)

        page.append(grid)

        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_halign(Gtk.Align.CENTER)

        back_btn = Gtk.Button(label=_("← Back"))
        _add_class(back_btn, "nav-btn-back")
        back_btn.connect("clicked", lambda _: self._go_to("windows"))
        nav.append(back_btn)

        next_btn = Gtk.Button(label=_("Next →"))
        _add_class(next_btn, "nav-btn-next")
        next_btn.connect("clicked", lambda _: self._go_to("ready"))
        nav.append(next_btn)

        page.append(nav)

        return page

    def _build_feature_card(self, icon: str, feat_title: str, feat_desc: str) -> Gtk.Box:
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        card.set_hexpand(True)
        _add_class(card, "feature-card")

        icon_lbl = Gtk.Image.new_from_icon_name(icon)
        icon_lbl.set_pixel_size(24)
        _add_class(icon_lbl, "feature-icon")
        icon_lbl.set_halign(Gtk.Align.START)
        card.append(icon_lbl)

        title_lbl = Gtk.Label(label=feat_title)
        _add_class(title_lbl, "feature-title")
        title_lbl.set_halign(Gtk.Align.START)
        card.append(title_lbl)

        desc_lbl = Gtk.Label(label=feat_desc)
        _add_class(desc_lbl, "feature-desc")
        desc_lbl.set_halign(Gtk.Align.START)
        desc_lbl.set_wrap(True)
        desc_lbl.set_xalign(0.0)
        card.append(desc_lbl)

        return card

    # ------------------------------------------------------------------
    # PAGE 4 — Ready
    # ------------------------------------------------------------------

    def _build_page_ready(self) -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_halign(Gtk.Align.CENTER)
        page.set_valign(Gtk.Align.FILL)
        page.set_margin_top(40)
        page.set_margin_bottom(24)
        page.set_margin_start(40)
        page.set_margin_end(40)

        check_lbl = Gtk.Label(label="✓")
        _add_class(check_lbl, "check-icon")
        check_lbl.set_margin_bottom(4)
        page.append(check_lbl)

        title = Gtk.Label(label=_("You're All Set!"))
        _add_class(title, "page-title")
        title.set_justify(Gtk.Justification.CENTER)
        page.append(title)

        subtitle = Gtk.Label(label=_("Try Super+Space to open the Intent Bar."))
        _add_class(subtitle, "page-subtitle")
        subtitle.set_justify(Gtk.Justification.CENTER)
        subtitle.set_wrap(True)
        page.append(subtitle)

        # Show on startup toggle
        toggle_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        toggle_row.set_halign(Gtk.Align.CENTER)
        toggle_row.set_margin_top(16)

        toggle_lbl = Gtk.Label(label=_("Show on startup:"))
        _add_class(toggle_lbl, "page-subtitle")
        toggle_row.append(toggle_lbl)

        switch = Gtk.Switch()
        switch.set_active(True)
        switch.connect("state-set", self._on_startup_toggle)
        toggle_row.append(switch)

        page.append(toggle_row)

        # Documentation & Community links
        links_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        links_row.set_halign(Gtk.Align.CENTER)
        links_row.set_margin_top(12)

        doc_btn = Gtk.LinkButton.new_with_label(
            "https://github.com/axonos/axon-os", "Documentation"
        )
        _add_class(doc_btn, "page-subtitle")
        links_row.append(doc_btn)

        comm_btn = Gtk.LinkButton.new_with_label(
            "https://github.com/axonos/axon-os/discussions", "Community"
        )
        _add_class(comm_btn, "page-subtitle")
        links_row.append(comm_btn)

        page.append(links_row)

        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        page.append(spacer)

        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_halign(Gtk.Align.CENTER)

        back_btn = Gtk.Button(label=_("← Back"))
        _add_class(back_btn, "nav-btn-back")
        back_btn.connect("clicked", lambda _: self._go_to("features"))
        nav.append(back_btn)

        start_btn = Gtk.Button(label=_("Start Using Axon"))
        _add_class(start_btn, "nav-btn-next")
        start_btn.connect("clicked", lambda _: self.close())
        nav.append(start_btn)

        page.append(nav)

        return page

    # ------------------------------------------------------------------
    # Startup toggle
    # ------------------------------------------------------------------

    def _on_startup_toggle(self, switch: Gtk.Switch, state: bool) -> bool:
        config_dir = os.path.expanduser("~/.config/axon-os")
        marker = os.path.join(config_dir, ".firstboot-done")
        if state:
            if os.path.exists(marker):
                try:
                    os.remove(marker)
                except OSError:
                    pass
        else:
            os.makedirs(config_dir, exist_ok=True)
            try:
                with open(marker, "w") as f:
                    f.write("")
            except OSError:
                pass
        return False
