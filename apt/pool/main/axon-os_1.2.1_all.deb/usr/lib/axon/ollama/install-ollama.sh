#!/usr/bin/env bash
# Axon OS — install a pinned Ollama release, verified by SHA-256.
#
# Replaces `curl https://ollama.com/install.sh | sh`, which ran unverified
# remote code as root. Downloads the release tarball named in
# ollama-release.env, checks it against the pinned hash, and installs it with
# a dedicated `ollama` system user and systemd unit. Must run as root.
#
# Usage: install-ollama.sh [--cpu-only]
#   --cpu-only  Install the program and its CPU libraries only (about 50 MB), leave out the
#               NVIDIA CUDA, AMD ROCm and Vulkan libraries (over 2 GB), and do not start or
#               enable the service. This is what the ISO ships; the GPU libraries are
#               added later by install-ollama-gpu.sh once a graphics card is detected.
#
# Exit codes: 0 installed (or already present), 1 failure, 3 no pinned hash.
set -euo pipefail

CPU_ONLY=false
for arg in "$@"; do
    case "${arg}" in
        --cpu-only) CPU_ONLY=true ;;
        *) echo "[install-ollama] unknown option: ${arg}" >&2; exit 2 ;;
    esac
done

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIN_FILE="${OLLAMA_PIN_FILE:-${HERE}/ollama-release.env}"
PREFIX="/usr/local"

log() { echo "[install-ollama] $*"; }

[[ ${EUID} -eq 0 ]] || { log "must run as root"; exit 1; }
[[ -f "${PIN_FILE}" ]] || { log "pin file not found: ${PIN_FILE}"; exit 3; }
# shellcheck source=/dev/null
source "${PIN_FILE}"

if [[ -z "${OLLAMA_VERSION:-}" || -z "${OLLAMA_SHA256:-}" || -z "${OLLAMA_ASSET:-}" ]]; then
    log "no pinned Ollama release in ${PIN_FILE}; refusing to install unverified code"
    log "pin one with: bash scripts/pin-ollama.sh <version>"
    exit 3
fi

# Enable and start the service when running on a booted system (not in a
# chroot), so the API is up as soon as this script returns.
start_service() {
    [[ "${CPU_ONLY}" == "true" ]] && return 0
    if [[ -d /run/systemd/system ]] && [[ -f /etc/systemd/system/ollama.service ]]; then
        systemctl daemon-reload 2>/dev/null || true
        systemctl enable --now ollama.service 2>/dev/null || log "WARNING: could not start ollama.service"
    fi
}

# GPU access: AMD (ROCm) and Intel need /dev/kfd and /dev/dri/render*,
# owned by the render and video groups. Without them Ollama silently falls
# back to the CPU. Also let the desktop user read the shared model store.
setup_groups() {
    id ollama >/dev/null 2>&1 || return 0
    local g
    for g in render video; do
        getent group "${g}" >/dev/null 2>&1 && usermod -a -G "${g}" ollama
    done
    if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
        usermod -a -G ollama "${SUDO_USER}" || true
    fi
}

if command -v ollama >/dev/null 2>&1; then
    log "ollama already installed at $(command -v ollama)"
    setup_groups
    start_service
    exit 0
fi

if [[ "${OLLAMA_ASSET}" == *.tar.zst ]] && ! command -v zstd >/dev/null 2>&1; then
    log "zstd is required to unpack ${OLLAMA_ASSET}; install it first (apt install zstd)"
    exit 1
fi

url="https://github.com/ollama/ollama/releases/download/${OLLAMA_VERSION}/${OLLAMA_ASSET}"
tmp="$(mktemp -d /var/tmp/axon-ollama.XXXXXX)"
trap 'rm -rf "${tmp}"' EXIT

# The tarball is about 2 GB (it carries the GPU libraries even for a --cpu-only install), so it is
# kept between runs: a rebuild, or a retry after a dropped connection, must not start from zero.
# The build mounts a directory that outlives the chroot at the default (build/build.sh).
# shellcheck source=/dev/null
source "${HERE}/download-cached.sh"
archive="$(fetch_cached "${url}" "${OLLAMA_SHA256}" "${OLLAMA_ASSET}" \
    "${AXON_DOWNLOAD_CACHE:-/var/cache/axon-downloads}" "${tmp}")" || exit 1

log "extracting into ${PREFIX}"
# GPU backends are separate directories under lib/ollama (cuda_v12, cuda_v13, rocm_*, vulkan)
skip=()
[[ "${CPU_ONLY}" == "true" ]] && skip=(--exclude='lib/ollama/cuda_*' --exclude='lib/ollama/rocm*' --exclude='lib/ollama/vulkan')
case "${OLLAMA_ASSET}" in
    *.tgz|*.tar.gz) tar -xzf "${archive}" -C "${PREFIX}" "${skip[@]}" ;;
    *.tar.zst) tar --zstd -xf "${archive}" -C "${PREFIX}" "${skip[@]}" ;;
    *) log "unsupported asset type: ${OLLAMA_ASSET}"; exit 1 ;;
esac

if ! id ollama >/dev/null 2>&1; then
    useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama
fi
setup_groups

cat > /etc/systemd/system/ollama.service <<UNIT
[Unit]
Description=Ollama Service
Wants=network-online.target
After=network-online.target

[Service]
ExecStart=${PREFIX}/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
# The service stays on, but an idle model leaves GPU memory after 5 minutes (Ollama's default,
# written down so it is not changed by accident). Game mode unloads models at once.
Environment="OLLAMA_KEEP_ALIVE=5m"

[Install]
WantedBy=multi-user.target
UNIT

start_service
log "installed Ollama ${OLLAMA_VERSION}$([[ "${CPU_ONLY}" == "true" ]] && echo " (CPU only)")"
