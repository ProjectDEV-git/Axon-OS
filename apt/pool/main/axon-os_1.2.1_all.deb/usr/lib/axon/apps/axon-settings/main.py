#!/usr/bin/env python3
"""
main.py — Entry point for the Axon Settings Assistant.
A GTK4 + libadwaita assistant to configure system settings via natural language.
"""

from __future__ import annotations

import sys
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
from gi.repository import Adw, GLib, Gtk, Pango

# Sibling import resolution
sys.path.insert(0, str(Path(__file__).resolve().parent))
from ai_models import AIModelsWindow
from diagnostics_window import DiagnosticsWindow
from preferences_window import PreferencesWindow

# Shared GTK helpers live in apps/shared next to every app
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "shared"))
from axon_gtk_utils import load_app_css
from settings_executor import SettingsExecutor

# Translations (services/i18n.py); plain English when services/ isn't found
for _base in (*Path(__file__).resolve().parents, Path("/usr/lib/axon")):
    if (_base / "services" / "i18n.py").is_file():
        sys.path.insert(0, str(_base / "services"))
        break
try:
    from i18n import _
except ImportError:

    def _(text: str) -> str:  # type: ignore[no-redef]
        return text


class AxonSettingsWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)
        self.set_title(_("Axon Assistant"))
        self.set_default_size(560, 420)
        self._timer_ids: list[int] = []
        self.connect("destroy", self._on_destroy)

        self._executor = SettingsExecutor()

        load_app_css(Path(__file__).resolve().parent / "main.css")

        # Main Layout
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_content(root)

        # Header Bar
        header = Adw.HeaderBar()
        header.add_css_class("settings-header")
        diagnostics_btn = Gtk.Button(icon_name="utilities-system-monitor-symbolic")
        diagnostics_btn.set_tooltip_text(_("Diagnostics: check that everything is working"))
        diagnostics_btn.update_property([Gtk.AccessibleProperty.LABEL], ["Diagnostics"])
        diagnostics_btn.connect("clicked", lambda _b: self.open_diagnostics())
        header.pack_start(diagnostics_btn)
        prefs_btn = Gtk.Button(icon_name="preferences-system-symbolic")
        prefs_btn.set_tooltip_text(_("Preferences: Spaces, privacy and command approvals"))
        prefs_btn.update_property([Gtk.AccessibleProperty.LABEL], ["Preferences"])
        prefs_btn.connect("clicked", lambda _b: self.open_preferences())
        header.pack_start(prefs_btn)
        models_btn = Gtk.Button(label=_("AI Models"))
        models_btn.set_tooltip_text(_("Choose AI models and providers"))
        models_btn.connect("clicked", lambda _b: self.open_ai_models())
        header.pack_end(models_btn)
        root.append(header)

        # Content Container
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        content_box.set_spacing(16)
        content_box.set_margin_start(24)
        content_box.set_margin_end(24)
        content_box.set_margin_top(16)
        content_box.set_margin_bottom(16)
        content_box.set_vexpand(True)
        root.append(content_box)

        # AI Status Icon & Title
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        title_box.set_spacing(12)
        title_box.set_halign(Gtk.Align.CENTER)

        ai_badge = Gtk.Label(label="⬡")
        ai_badge.add_css_class("ai-badge-icon")
        title_box.append(ai_badge)

        app_title = Gtk.Label(label=_("System Assistant"))
        app_title.add_css_class("app-title-label")
        title_box.append(app_title)

        content_box.append(title_box)

        # Feedback Bubble / Card
        self._feedback_card = Gtk.Frame()
        self._feedback_card.add_css_class("feedback-card")

        feedback_inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        feedback_inner.set_spacing(8)
        feedback_inner.set_margin_start(16)
        feedback_inner.set_margin_end(16)
        feedback_inner.set_margin_top(16)
        feedback_inner.set_margin_bottom(16)

        self._feedback_text = Gtk.Label(
            label=_(
                "Tell me what you'd like to adjust. Try: 'toggle dark mode', 'enable night light', 'turn on bluetooth', or 'enable do not disturb'."
            )
        )
        self._feedback_text.set_wrap(True)
        self._feedback_text.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self._feedback_text.set_xalign(0.5)
        self._feedback_text.add_css_class("feedback-text")

        feedback_inner.append(self._feedback_text)
        self._feedback_card.set_child(feedback_inner)
        content_box.append(self._feedback_card)

        # Quick Control Panel (visual representation of system actions)
        quick_grid = Gtk.Grid()
        quick_grid.set_column_spacing(16)
        quick_grid.set_row_spacing(12)
        quick_grid.set_halign(Gtk.Align.CENTER)
        quick_grid.set_margin_top(8)

        # Dark Mode button
        dark_btn = Gtk.Button(label=_("Toggle Theme"))
        dark_btn.add_css_class("quick-action-btn")
        dark_btn.connect("clicked", lambda _b: self._run_command("toggle dark mode"))
        quick_grid.attach(dark_btn, 0, 0, 1, 1)

        # WiFi button
        wifi_btn = Gtk.Button(label=_("Toggle Wi-Fi"))
        wifi_btn.add_css_class("quick-action-btn")
        wifi_btn.connect("clicked", lambda _b: self._run_command("toggle wifi"))
        quick_grid.attach(wifi_btn, 1, 0, 1, 1)

        # Mute button
        mute_btn = Gtk.Button(label=_("Toggle Mute"))
        mute_btn.add_css_class("quick-action-btn")
        mute_btn.connect("clicked", lambda _b: self._run_command("mute audio"))
        quick_grid.attach(mute_btn, 0, 1, 1, 1)

        # Max Brightness button
        bright_btn = Gtk.Button(label=_("Max Brightness"))
        bright_btn.add_css_class("quick-action-btn")
        bright_btn.connect("clicked", lambda _b: self._run_command("set brightness to 100%"))
        quick_grid.attach(bright_btn, 1, 1, 1, 1)

        # Night Light button
        night_btn = Gtk.Button(label=_("Toggle Night Light"))
        night_btn.add_css_class("quick-action-btn")
        night_btn.connect("clicked", lambda _b: self._run_command("toggle night light"))
        quick_grid.attach(night_btn, 0, 2, 1, 1)

        # Bluetooth button
        bt_btn = Gtk.Button(label=_("Toggle Bluetooth"))
        bt_btn.add_css_class("quick-action-btn")
        bt_btn.connect("clicked", lambda _b: self._run_command("toggle bluetooth"))
        quick_grid.attach(bt_btn, 1, 2, 1, 1)

        # Do Not Disturb button
        dnd_btn = Gtk.Button(label=_("Toggle DND"))
        dnd_btn.add_css_class("quick-action-btn")
        dnd_btn.connect("clicked", lambda _b: self._run_command("toggle do not disturb"))
        quick_grid.attach(dnd_btn, 0, 3, 1, 1)

        # Natural Scroll button
        scroll_btn = Gtk.Button(label=_("Toggle Natural Scroll"))
        scroll_btn.add_css_class("quick-action-btn")
        scroll_btn.connect("clicked", lambda _b: self._run_command("toggle natural scrolling"))
        quick_grid.attach(scroll_btn, 1, 3, 1, 1)

        content_box.append(quick_grid)

        # Input box at the bottom
        input_container = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        input_container.set_spacing(10)
        input_container.add_css_class("input-container")
        input_container.set_margin_start(24)
        input_container.set_margin_end(24)
        input_container.set_margin_bottom(24)

        self._entry = Gtk.Entry()
        self._entry.set_hexpand(True)
        self._entry.set_placeholder_text(_("Ask the assistant to configure something..."))
        self._entry.connect("activate", self._on_entry_activated)
        self._entry.add_css_class("settings-input-entry")
        input_container.append(self._entry)

        send_btn = Gtk.Button(label=_("Apply"))
        send_btn.add_css_class("settings-apply-btn")
        send_btn.connect("clicked", lambda _b: self._on_entry_activated(self._entry))
        input_container.append(send_btn)

        root.append(input_container)

        self._entry.grab_focus()

    def open_diagnostics(self) -> None:
        DiagnosticsWindow(transient_for=self, application=self.get_application()).present()

    def open_preferences(self) -> None:
        PreferencesWindow(transient_for=self, application=self.get_application()).present()

    def open_ai_models(self) -> None:
        AIModelsWindow(transient_for=self, application=self.get_application()).present()

    def _on_entry_activated(self, entry: Gtk.Entry) -> None:
        text = entry.get_text().strip()
        if not text:
            return
        entry.set_text("")
        self._run_command(text)

    def _run_command(self, query: str) -> None:
        self._feedback_text.set_text(_("Applying settings change..."))
        self._feedback_card.add_css_class("loading")

        # Async execution helper
        def worker():
            res = self._executor.execute_command(query)
            GLib.idle_add(self._on_command_completed, res)

        import threading

        threading.Thread(target=worker, daemon=True).start()

    def _on_command_completed(self, result: dict) -> None:
        if not self.get_realized():
            return
        self._feedback_card.remove_css_class("loading")
        msg = result.get("message", "Request completed.")
        self._feedback_text.set_text(msg)
        if result.get("success"):
            self._feedback_card.add_css_class("success")
            tid = GLib.timeout_add(
                1500, lambda: self._feedback_card.remove_css_class("success") or False
            )
            self._timer_ids.append(tid)
        else:
            self._feedback_card.add_css_class("error")
            tid = GLib.timeout_add(
                2000, lambda: self._feedback_card.remove_css_class("error") or False
            )
            self._timer_ids.append(tid)

    def _on_destroy(self, _widget: Gtk.Widget) -> None:
        for tid in self._timer_ids:
            try:
                GLib.source_remove(tid)
            except Exception:
                pass
        self._timer_ids.clear()


class AxonSettingsApp(Adw.Application):
    def __init__(self) -> None:
        super().__init__(application_id="io.github.axon_os.SettingsAssistant")
        self._window: AxonSettingsWindow | None = None

    def do_activate(self) -> None:
        if self._window is None:
            self._window = AxonSettingsWindow(application=self)
        self._window.present()
        if "--diagnostics" in sys.argv:
            self._window.open_diagnostics()
        if "--ai-models" in sys.argv:
            self._window.open_ai_models()
        if "--preferences" in sys.argv:
            self._window.open_preferences()


def main() -> int:
    app = AxonSettingsApp()
    # GApplication rejects unknown options; ours are read in do_activate
    ours = ("--ai-models", "--diagnostics", "--preferences")
    return app.run([arg for arg in sys.argv if arg not in ours])


if __name__ == "__main__":
    sys.exit(main())
