#!/usr/bin/env python3
"""Axon Files — Window and layout components."""

import shutil
import stat
import subprocess
import sys
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
from file_indexer import FileIndexer, format_size, format_timestamp
from gi.repository import Adw, Gdk, Gio, GLib, Gtk

# Shared GTK helpers live in apps/shared next to every app
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "shared"))
from axon_gtk_utils import fit_default_size, load_app_css

for _base in (Path(__file__).resolve().parents[2], Path(__file__).resolve().parents[1]):
    if (_base / "services").is_dir():
        sys.path.insert(0, str(_base / "services"))
        break
from i18n import _


def load_css():
    """Loads application CSS styling (design tokens first)."""
    load_app_css(Path(__file__).parent / "main.css")


class SidebarRow(Gtk.ListBoxRow):
    def __init__(self, name, icon_name, path_val):
        super().__init__()
        self.name = name
        self.path_val = path_val

        self.get_style_context().add_class("sidebar-item")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        icon = Gtk.Image.new_from_icon_name(icon_name)
        icon.set_pixel_size(18)
        box.append(icon)

        lbl = Gtk.Label(label=name)
        lbl.set_halign(Gtk.Align.START)
        box.append(lbl)

        self.set_child(box)


class FileRow(Gtk.ListBoxRow):
    def __init__(self, item):
        super().__init__()
        self.file_info = item

        self.get_style_context().add_class("file-row")

        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

        # Icon based on type
        if item.get("is_dir", False):
            icon_name = "folder-symbolic"
        else:
            ftype = item.get("file_type", "").lower()
            if ftype in ["jpg", "jpeg", "png", "gif", "svg", "bmp", "webp"]:
                icon_name = "image-x-generic-symbolic"
            elif ftype in ["mp3", "ogg", "wav", "flac", "m4a"]:
                icon_name = "audio-x-generic-symbolic"
            elif ftype in ["mp4", "mkv", "avi", "mov", "webm"]:
                icon_name = "video-x-generic-symbolic"
            elif ftype in [
                "py",
                "js",
                "ts",
                "tsx",
                "jsx",
                "rs",
                "c",
                "cpp",
                "h",
                "sh",
                "html",
                "css",
                "toml",
                "json",
                "yaml",
                "yml",
            ]:
                icon_name = "text-x-script-symbolic"
            else:
                icon_name = "text-x-generic-symbolic"

        icon = Gtk.Image.new_from_icon_name(icon_name)
        icon.set_pixel_size(24)
        hbox.append(icon)

        # Text details
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        vbox.set_hexpand(True)

        name_lbl = Gtk.Label(label=item["file_name"])
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.get_style_context().add_class("file-name-label")
        name_lbl.set_ellipsize(3)  # Pango.EllipsizeMode.END
        vbox.append(name_lbl)

        # Show path or snippet
        path_lbl = Gtk.Label(label=item["file_path"])
        path_lbl.set_halign(Gtk.Align.START)
        path_lbl.get_style_context().add_class("file-path-label")
        path_lbl.set_ellipsize(3)
        vbox.append(path_lbl)

        hbox.append(vbox)

        # Similarity score badge
        sim = item.get("similarity", 0.0)
        if sim > 0:
            sim_pct = int(sim * 100)
            sim_badge = Gtk.Label()
            sim_badge.set_markup(f"<span class='badge-similarity'>AI Match {sim_pct}%</span>")
            sim_badge.get_style_context().add_class("badge-similarity")
            hbox.append(sim_badge)

        # File type badge
        if not item.get("is_dir", False) and item.get("file_type"):
            type_badge = Gtk.Label(label=item["file_type"].upper())
            type_badge.get_style_context().add_class("badge-type")
            hbox.append(type_badge)

        # File size
        size_str = format_size(item["file_size"])
        size_lbl = Gtk.Label(label=size_str)
        size_lbl.get_style_context().add_class("file-meta-label")
        size_lbl.set_width_chars(10)
        size_lbl.set_xalign(1.0)
        hbox.append(size_lbl)

        # Modified date
        date_str = format_timestamp(item["last_modified"])
        date_lbl = Gtk.Label(label=date_str)
        date_lbl.get_style_context().add_class("file-meta-label")
        date_lbl.set_width_chars(18)
        date_lbl.set_xalign(1.0)
        hbox.append(date_lbl)

        self.set_child(hbox)


class FilesWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title(_("Axon Files"))
        fit_default_size(self, 1000, 680)

        self.indexer = FileIndexer()
        self.current_dir = None
        self.search_query = ""
        self.use_semantic = False
        self.clipboard_file = None
        self.clipboard_action = None

        # Background worker sync state
        self.sync_thread = None

        # Load external stylesheet
        load_css()
        self.get_style_context().add_class("window-bg")

        # Top-level Box
        root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # Header bar
        header = Adw.HeaderBar()

        # Sync index button + Spinner
        sync_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        self.spinner = Gtk.Spinner()
        sync_box.append(self.spinner)

        self.sync_btn = Gtk.Button(label=_("Sync Index"))
        self.sync_btn.get_style_context().add_class("sync-btn")
        self.sync_btn.connect("clicked", self.on_sync_clicked)
        sync_box.append(self.sync_btn)

        header.pack_start(sync_box)

        # Search Box in center of HeaderBar
        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)

        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Search files, folders or content..."))
        self.search_entry.set_width_chars(32)
        self.search_entry.connect("search-changed", self.on_search_changed)
        search_box.append(self.search_entry)

        # AI Semantic Search Toggle
        self.ai_toggle = Gtk.ToggleButton(label=_("AI Search"))
        self.ai_toggle.get_style_context().add_class("ai-toggle-btn")
        self.ai_toggle.connect("toggled", self.on_ai_toggled)
        search_box.append(self.ai_toggle)

        header.set_title_widget(search_box)

        root_box.append(header)

        # Split layout: Sidebar, Main Area, Preview Panel
        layout_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)

        # Left Panel (Sidebar)
        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sidebar_box.get_style_context().add_class("sidebar")
        sidebar_box.set_size_request(200, -1)

        sidebar_title = Gtk.Label(label=_("Places"))
        sidebar_title.set_halign(Gtk.Align.START)
        sidebar_title.set_margin_top(16)
        sidebar_title.set_margin_bottom(8)
        sidebar_title.set_margin_start(16)
        sidebar_title.get_style_context().add_class("file-path-label")
        sidebar_box.append(sidebar_title)

        self.sidebar_list = Gtk.ListBox()
        self.sidebar_list.get_style_context().add_class("sidebar-list")
        self.sidebar_list.connect("row-selected", self.on_sidebar_selected)

        # Populate sidebar items
        self.sidebar_list.append(SidebarRow("Search Index", "system-search-symbolic", None))
        self.sidebar_list.append(SidebarRow("Home", "user-home-symbolic", str(Path.home())))
        self.sidebar_list.append(
            SidebarRow("Documents", "folder-documents-symbolic", str(Path.home() / "Documents"))
        )
        self.sidebar_list.append(
            SidebarRow("Downloads", "folder-download-symbolic", str(Path.home() / "Downloads"))
        )
        self.sidebar_list.append(
            SidebarRow("Desktop", "user-desktop-symbolic", str(Path.home() / "Desktop"))
        )
        self.sidebar_list.append(
            SidebarRow("Pictures", "folder-pictures-symbolic", str(Path.home() / "Pictures"))
        )
        self.sidebar_list.append(
            SidebarRow("Videos", "folder-videos-symbolic", str(Path.home() / "Videos"))
        )
        self.sidebar_list.append(
            SidebarRow("Music", "folder-music-symbolic", str(Path.home() / "Music"))
        )

        sidebar_box.append(self.sidebar_list)
        layout_box.append(sidebar_box)

        # Center Panel (Main Content)
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        main_box.get_style_context().add_class("main-content")
        main_box.set_hexpand(True)

        # Breadcrumbs/Path bar
        self.path_bar_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.path_bar_box.get_style_context().add_class("path-bar")
        main_box.append(self.path_bar_box)

        # Scrolled file list
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)

        self.file_list = Gtk.ListBox()
        self.file_list.get_style_context().add_class("file-list")
        self.file_list.connect("row-selected", self.on_file_selected)
        self.file_list.connect("row-activated", self.on_file_activated)

        # Right-click gesture
        list_gesture = Gtk.GestureClick.new()
        list_gesture.set_button(3)
        list_gesture.connect("pressed", self.on_list_right_clicked)
        self.file_list.add_controller(list_gesture)

        # Keyboard shortcuts controller
        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self.on_key_pressed)
        self.add_controller(key_controller)

        scroll.set_child(self.file_list)
        main_box.append(scroll)

        # Bottom status label
        self.status_lbl = Gtk.Label(label=_("Index state: Loading..."))
        self.status_lbl.set_halign(Gtk.Align.START)
        self.status_lbl.get_style_context().add_class("file-path-label")
        self.status_lbl.set_margin_top(8)
        main_box.append(self.status_lbl)

        layout_box.append(main_box)

        # Right Panel (AI Preview)
        self.preview_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.preview_panel.get_style_context().add_class("preview-panel")

        # Placeholder details
        self.preview_placeholder = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.preview_placeholder.set_valign(Gtk.Align.CENTER)
        self.preview_placeholder.set_vexpand(True)

        ph_icon = Gtk.Image.new_from_icon_name("document-open-symbolic")
        ph_icon.set_pixel_size(48)
        ph_icon.set_opacity(0.3)
        self.preview_placeholder.append(ph_icon)

        self.ph_lbl = Gtk.Label(label=_("Select a file to preview AI details"))
        self.ph_lbl.set_justify(Gtk.Justification.CENTER)
        self.ph_lbl.get_style_context().add_class("file-meta-label")
        self.preview_placeholder.append(self.ph_lbl)

        self.preview_panel.append(self.preview_placeholder)

        # Detailed preview box
        self.preview_details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.preview_details.set_visible(False)

        self.prev_title = Gtk.Label()
        self.prev_title.get_style_context().add_class("preview-title")
        self.prev_title.set_halign(Gtk.Align.START)
        self.prev_title.set_wrap(True)
        self.prev_title.set_max_width_chars(25)
        self.preview_details.append(self.prev_title)

        self.prev_meta = Gtk.Label()
        self.prev_meta.get_style_context().add_class("preview-meta")
        self.prev_meta.set_halign(Gtk.Align.START)
        self.prev_meta.set_wrap(True)
        self.preview_details.append(self.prev_meta)

        summary_title = Gtk.Label(label=_("AI Content Summary:"))
        summary_title.set_halign(Gtk.Align.START)
        summary_title.get_style_context().add_class("file-name-label")
        self.preview_details.append(summary_title)

        prev_scroll = Gtk.ScrolledWindow()
        prev_scroll.set_size_request(-1, 250)
        prev_scroll.set_vexpand(True)

        self.prev_summary = Gtk.TextView()
        self.prev_summary.set_editable(False)
        self.prev_summary.set_wrap_mode(Gtk.WrapMode.WORD)
        self.prev_summary.get_style_context().add_class("preview-summary-box")
        prev_scroll.set_child(self.prev_summary)

        self.preview_details.append(prev_scroll)

        # Action Open button
        self.open_btn = Gtk.Button(label=_("Open File"))
        self.open_btn.get_style_context().add_class("sync-btn")
        self.open_btn.connect("clicked", self.on_open_clicked)
        self.preview_details.append(self.open_btn)

        self.preview_panel.append(self.preview_details)
        layout_box.append(self.preview_panel)

        root_box.append(layout_box)
        self.set_content(root_box)

        # Select first row in sidebar ("Search Index")
        self.sidebar_list.select_row(self.sidebar_list.get_row_at_index(0))
        self.update_status_label()

    def update_status_label(self):
        """Updates the status line indicating how many files are indexed."""
        try:
            count = self.indexer.get_indexed_count()
            self.status_lbl.set_text(f"Index state: {count} files semantically indexed.")
        except Exception:
            self.status_lbl.set_text(_("Index state: Database offline."))

    def on_sidebar_selected(self, listbox, row):
        if row is None:
            return
        self.current_dir = row.path_val
        self.refresh_list()
        self.update_path_bar()

    def navigate_to(self, target_path):
        """Helper to navigate via breadcrumbs."""
        self.current_dir = str(target_path)
        self.refresh_list()
        self.update_path_bar()

        # Match sidebar selection if it matches one of the root folders
        for idx in range(8):
            row = self.sidebar_list.get_row_at_index(idx)
            if row and row.path_val == self.current_dir:
                self.sidebar_list.select_row(row)
                return
        # If no sidebar row matches, clear selection safely
        self.sidebar_list.select_row(None)

    def update_path_bar(self):
        """Draws breadcrumbs matching current_dir."""
        # Clear path bar
        while child := self.path_bar_box.get_first_child():
            self.path_bar_box.remove(child)

        # Container for breadcrumbs trail
        breadcrumbs_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        breadcrumbs_box.set_hexpand(True)
        self.path_bar_box.append(breadcrumbs_box)

        if self.current_dir is None:
            lbl = Gtk.Label(label=_("Search All Folders"))
            lbl.get_style_context().add_class("file-name-label")
            breadcrumbs_box.append(lbl)
        else:
            path_obj = Path(self.current_dir).expanduser().resolve()
            parts = []
            curr = path_obj
            while curr != curr.parent:
                parts.append(curr)
                curr = curr.parent
            parts.append(curr)  # Root folder
            parts.reverse()

            first = True
            for p in parts:
                if not first:
                    sep = Gtk.Label(label=" › ")
                    sep.get_style_context().add_class("file-meta-label")
                    breadcrumbs_box.append(sep)
                first = False

                name = "Home" if p == Path.home() else (p.name if p.name else "/")
                btn = Gtk.Button(label=name)
                btn.get_style_context().add_class("path-btn")
                btn.set_has_frame(False)
                btn.connect("clicked", lambda b, target=p: self.navigate_to(target))
                breadcrumbs_box.append(btn)

        # Action buttons on the right if viewing folder
        if self.current_dir is not None:
            actions_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

            # New Folder Button
            new_dir_btn = Gtk.Button()
            new_dir_btn.set_icon_name("folder-new-symbolic")
            new_dir_btn.set_tooltip_text(_("New Folder"))
            new_dir_btn.get_style_context().add_class("path-btn")
            new_dir_btn.set_has_frame(False)
            new_dir_btn.connect("clicked", lambda b: self.create_new_folder_dialog())
            actions_box.append(new_dir_btn)

            # New File Button
            new_file_btn = Gtk.Button()
            new_file_btn.set_icon_name("document-new-symbolic")
            new_file_btn.set_tooltip_text(_("New File"))
            new_file_btn.get_style_context().add_class("path-btn")
            new_file_btn.set_has_frame(False)
            new_file_btn.connect("clicked", lambda b: self.create_new_file_dialog())
            actions_box.append(new_file_btn)

            # Paste Button
            paste_btn = Gtk.Button()
            paste_btn.set_icon_name("edit-paste-symbolic")
            paste_btn.set_tooltip_text(_("Paste"))
            paste_btn.get_style_context().add_class("path-btn")
            paste_btn.set_has_frame(False)
            paste_btn.set_sensitive(self.clipboard_file is not None)
            paste_btn.connect("clicked", lambda b: self.paste_file())
            actions_box.append(paste_btn)

            self.path_bar_box.append(actions_box)

    def refresh_list(self):
        """Updates the list of files in the center view."""
        # Clear files ListBox
        while child := self.file_list.get_first_child():
            self.file_list.remove(child)

        if self.search_query.strip():
            # If search is active, query database
            results = self.indexer.search_local(self.search_query, use_semantic=self.use_semantic)

            # Apply folder filtering if browsing directory
            if self.current_dir is not None:
                filtered = []
                curr_path = Path(self.current_dir).expanduser().resolve()
                for r in results:
                    try:
                        r_path = Path(r["file_path"]).expanduser().resolve()
                        if curr_path in r_path.parents or curr_path == r_path:
                            filtered.append(r)
                    except Exception:
                        pass
                results = filtered
        else:
            # If browsing folder
            if self.current_dir is not None:
                results = list_directory_contents(self.current_dir, self.indexer)
            else:
                # Global index view (shows 50 latest indexed files)
                results = self.indexer.search_local("")

        # Populate ListBox
        for item in results:
            self.file_list.append(FileRow(item))

    def on_search_changed(self, entry):
        self.search_query = entry.get_text()
        self.refresh_list()

    def on_ai_toggled(self, btn):
        self.use_semantic = btn.get_active()
        self.refresh_list()

    def on_file_selected(self, listbox, row):
        if row is None or not hasattr(row, "file_info"):
            self.show_preview_placeholder()
            return

        info = row.file_info
        if info.get("is_dir", False):
            self.show_preview_placeholder(f"Folder: {info['file_name']}")
            return

        self.show_preview_details(info)

    def show_preview_placeholder(self, text="Select a file to preview AI details"):
        self.preview_placeholder.set_visible(True)
        self.preview_details.set_visible(False)
        self.ph_lbl.set_text(text)

    def show_preview_details(self, info):
        self.preview_placeholder.set_visible(False)
        self.preview_details.set_visible(True)

        self.prev_title.set_text(info["file_name"])

        size_str = format_size(info["file_size"])
        date_str = format_timestamp(info["last_modified"])
        meta = f"Type: {info.get('file_type', 'unknown').upper()}\nSize: {size_str}\nModified: {date_str}"

        # Add similarity match info to preview metadata
        sim = info.get("similarity", 0.0)
        if sim > 0:
            meta += f"\nAI Relevance: {int(sim * 100)}%"

        self.prev_meta.set_text(meta)

        # Load content summary
        buf = self.prev_summary.get_buffer()
        summary_text = info.get("content_summary", "")
        if not summary_text:
            summary_text = "[No text content or file not yet indexed]"
        buf.set_text(summary_text)

        self.selected_file_path = info["file_path"]

    def on_file_activated(self, listbox, row):
        if row is None or not hasattr(row, "file_info"):
            return
        info = row.file_info
        if info.get("is_dir", False):
            self.navigate_to(info["file_path"])
        else:
            self.open_file_path(info["file_path"])

    def on_open_clicked(self, btn):
        if hasattr(self, "selected_file_path") and self.selected_file_path:
            self.open_file_path(self.selected_file_path)

    def open_file_path(self, file_path):
        try:
            subprocess.Popen(["xdg-open", file_path])
        except Exception as e:
            from axon_logger import configure_app_logger

            logger = configure_app_logger(__name__)
            logger.exception("Error opening file %s: %s", file_path, e)

    # --- Sync Index background worker ---
    def on_sync_clicked(self, btn):
        if self.sync_thread and self.sync_thread.is_alive():
            return

        self.sync_btn.set_sensitive(False)
        self.spinner.start()

        # Get roots to scan
        scan_roots = self.get_default_scan_roots()

        self.status_lbl.set_text(_("Indexing background process started..."))

        # Setup cancel and progress tracking
        def progress_cb(current_path, indexed, total):
            GLib.idle_add(self.update_sync_progress, current_path, indexed, total)

        def done_cb(success, err):
            GLib.idle_add(self.sync_completed, success, err)

        # Spawn thread
        self.sync_thread = threading.Thread(
            target=self._run_scan, args=(scan_roots, progress_cb, done_cb), daemon=True
        )
        self.sync_thread.start()

    def get_default_scan_roots(self):
        """Scans standard folders plus root home directory files."""
        dirs = [
            Path.home() / "Documents",
            Path.home() / "Downloads",
            Path.home() / "Desktop",
            Path.home() / "Pictures",
            Path.home() / "Videos",
            Path.home() / "Music",
        ]
        roots = []
        for d in dirs:
            if d.exists():
                roots.append(str(d))
        # Add files in home root (non-recursive)
        try:
            for entry in Path.home().iterdir():
                if entry.is_file() and not entry.name.startswith("."):
                    roots.append(str(entry))
        except Exception:
            pass
        return roots

    def _run_scan(self, roots, progress_cb, done_cb):
        try:
            self.indexer.scan_directories(roots, progress_callback=progress_cb)
            done_cb(True, "")
        except Exception as e:
            done_cb(False, str(e))

    def update_sync_progress(self, path, indexed, total):
        if not self.get_realized():
            return False
        self.status_lbl.set_text(f"Indexing: {indexed} of {total} | {Path(path).name}")
        return False

    def sync_completed(self, success, err_msg):
        if not self.get_realized():
            return False
        self.spinner.stop()
        self.sync_btn.set_sensitive(True)
        if success:
            self.update_status_label()
            self.refresh_list()
        else:
            self.status_lbl.set_text(f"Indexing failed: {err_msg}")
        return False

    # --- File Operations handlers & helper functions ---

    def on_key_pressed(self, controller, keyval, keycode, state):
        keyname = Gdk.keyval_name(keyval)
        is_ctrl = (state & Gdk.ModifierType.CONTROL_MASK) != 0
        row = self.file_list.get_selected_row()

        if is_ctrl:
            if keyname == "c":
                if row and hasattr(row, "file_info"):
                    self.copy_file(row.file_info["file_path"])
                    return True
            elif keyname == "x":
                if row and hasattr(row, "file_info"):
                    self.cut_file(row.file_info["file_path"])
                    return True
            elif keyname == "v":
                self.paste_file()
                return True
            elif keyname == "n":
                self.create_new_folder_dialog()
                return True
        else:
            if keyname == "Delete":
                if row and hasattr(row, "file_info"):
                    self.trash_file(row.file_info["file_path"])
                    return True
            elif keyname == "F2":
                if row and hasattr(row, "file_info"):
                    self.rename_file(row.file_info["file_path"])
                    return True
        return False

    def on_list_right_clicked(self, gesture, n_press, x, y):
        row = self.file_list.get_row_at_y(int(y))
        if row:
            # Point to click coordinates (already relative to ListBox)
            self.show_context_menu(row, int(x), int(y))
        else:
            self.show_empty_context_menu(int(x), int(y))

    def show_context_menu(self, row, x, y):
        popover = Gtk.Popover()
        popover.set_parent(self.file_list)
        popover.set_has_arrow(True)
        rect = Gdk.Rectangle()
        rect.x = x
        rect.y = y
        rect.width = 1
        rect.height = 1
        popover.set_pointing_to(rect)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("sidebar-list")  # reusable CSS padding

        actions = [
            ("Open", "document-open-symbolic", lambda: self.on_file_activated(None, row)),
            ("Copy", "edit-copy-symbolic", lambda: self.copy_file(row.file_info["file_path"])),
            ("Cut", "edit-cut-symbolic", lambda: self.cut_file(row.file_info["file_path"])),
            (
                "Rename...",
                "document-properties-symbolic",
                lambda: self.rename_file(row.file_info["file_path"]),
            ),
            (
                "Move to Trash",
                "user-trash-symbolic",
                lambda: self.trash_file(row.file_info["file_path"]),
            ),
            (
                "Properties...",
                "dialog-information-symbolic",
                lambda: self.show_properties(row.file_info),
            ),
        ]

        for label, icon_name, callback in actions:
            btn = Gtk.Button()
            btn.set_has_frame(False)
            btn.get_style_context().add_class("path-btn")

            btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            icon = Gtk.Image.new_from_icon_name(icon_name)
            icon.set_pixel_size(16)
            btn_box.append(icon)

            lbl = Gtk.Label(label=label)
            lbl.set_halign(Gtk.Align.START)
            btn_box.append(lbl)

            btn.set_child(btn_box)

            def make_click(cb):
                return lambda b: (popover.popdown(), cb())

            btn.connect("clicked", make_click(callback))
            box.append(btn)

        popover.set_child(box)
        popover.popup()

    def show_empty_context_menu(self, x, y):
        popover = Gtk.Popover()
        popover.set_parent(self.file_list)
        popover.set_has_arrow(True)
        rect = Gdk.Rectangle()
        rect.x = x
        rect.y = y
        rect.width = 1
        rect.height = 1
        popover.set_pointing_to(rect)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("sidebar-list")

        actions = [
            ("New Folder...", "folder-new-symbolic", lambda: self.create_new_folder_dialog()),
            ("New File...", "document-new-symbolic", lambda: self.create_new_file_dialog()),
            ("Paste", "edit-paste-symbolic", lambda: self.paste_file()),
            ("Refresh List", "view-refresh-symbolic", lambda: self.refresh_list()),
        ]

        for label, icon_name, callback in actions:
            btn = Gtk.Button()
            btn.set_has_frame(False)
            btn.get_style_context().add_class("path-btn")

            btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            icon = Gtk.Image.new_from_icon_name(icon_name)
            icon.set_pixel_size(16)
            btn_box.append(icon)

            lbl = Gtk.Label(label=label)
            lbl.set_halign(Gtk.Align.START)
            btn_box.append(lbl)

            btn.set_child(btn_box)

            if label == "Paste":
                btn.set_sensitive(self.clipboard_file is not None)

            def make_click(cb):
                return lambda b: (popover.popdown(), cb())

            btn.connect("clicked", make_click(callback))
            box.append(btn)

        popover.set_child(box)
        popover.popup()

    def prompt_text_dialog(self, title, label_text, default_text, callback):
        transient = (
            self.get_root()
            if hasattr(self, "get_root") and hasattr(self.get_root(), "present")
            else None
        )
        dialog = Gtk.Dialog(title=title, transient_for=transient, modal=True)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("OK", Gtk.ResponseType.OK)

        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(12)
        box.set_margin_end(12)

        lbl = Gtk.Label(label=label_text)
        lbl.set_halign(Gtk.Align.START)
        box.append(lbl)

        entry = Gtk.Entry()
        entry.set_text(default_text)
        entry.set_activates_default(True)
        box.append(entry)

        dialog.set_default_response(Gtk.ResponseType.OK)

        def on_response(dlg, response_id):
            text = entry.get_text().strip()
            dialog.destroy()
            if response_id == Gtk.ResponseType.OK:
                callback(text)

        dialog.connect("response", on_response)
        dialog.present()
        entry.grab_focus()

    def copy_file(self, path):
        self.clipboard_file = path
        self.clipboard_action = "copy"
        self.status_lbl.set_text(f"Copied: {Path(path).name}")
        self.update_path_bar()

    def cut_file(self, path):
        self.clipboard_file = path
        self.clipboard_action = "cut"
        self.status_lbl.set_text(f"Cut: {Path(path).name}")
        self.update_path_bar()

    def paste_file(self):
        if not self.clipboard_file:
            return

        dest_dir = self.current_dir or str(Path.home())
        src_path = Path(self.clipboard_file)
        dest_path = Path(dest_dir) / src_path.name

        if not src_path.exists():
            self.status_lbl.set_text(_("Paste failed: Source file no longer exists."))
            return

        if dest_path.exists():
            dest_path = Path(dest_dir) / f"{src_path.stem}_copy{src_path.suffix}"

        try:
            if self.clipboard_action == "copy":
                if src_path.is_dir():
                    shutil.copytree(src_path, dest_path)
                else:
                    shutil.copy2(src_path, dest_path)
                self.status_lbl.set_text(f"Pasted: {src_path.name}")
            elif self.clipboard_action == "cut":
                shutil.move(str(src_path), str(dest_path))
                self.status_lbl.set_text(f"Moved: {src_path.name}")
                self.clipboard_file = None
                self.clipboard_action = None
            self.refresh_list()
            self.update_path_bar()
        except Exception as e:
            self.status_lbl.set_text(f"Paste failed: {e}")

    def rename_file(self, path):
        src = Path(path)

        def do_rename(new_name):
            if not new_name:
                return
            # Reject path traversal in new name
            if "/" in new_name or "\\" in new_name or ".." in new_name:
                self.status_lbl.set_text(_("Rename failed: invalid characters in name"))
                return
            dest = src.parent / new_name
            # Verify resolved path stays in same directory
            if dest.resolve().parent != src.parent.resolve():
                self.status_lbl.set_text(_("Rename failed: path escapes directory"))
                return
            try:
                src.rename(dest)
                self.status_lbl.set_text(f"Renamed to: {new_name}")
                self.refresh_list()
            except Exception as e:
                self.status_lbl.set_text(f"Rename failed: {e}")

        self.prompt_text_dialog("Rename", f"Enter new name for '{src.name}':", src.name, do_rename)

    def trash_file(self, path):
        transient = (
            self.get_root()
            if hasattr(self, "get_root") and hasattr(self.get_root(), "present")
            else None
        )
        dialog = Gtk.Dialog(title="Move to Trash", transient_for=transient, modal=True)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Move to Trash", Gtk.ResponseType.OK)

        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(12)
        box.set_margin_end(12)

        lbl = Gtk.Label(label=f"Move '{Path(path).name}' to Trash?")
        lbl.set_wrap(True)
        box.append(lbl)

        def on_response(dlg, response_id):
            dialog.destroy()
            if response_id == Gtk.ResponseType.OK:
                try:
                    f = Gio.File.new_for_path(path)
                    f.trash(None)
                    self.status_lbl.set_text(f"Moved to Trash: {Path(path).name}")
                    self.refresh_list()
                except Exception as e:
                    self.status_lbl.set_text(f"Failed to move to Trash: {e}")

        dialog.connect("response", on_response)
        dialog.present()

    def create_new_folder_dialog(self):
        dest_dir = self.current_dir or str(Path.home())

        def do_create(name):
            if not name:
                return
            # Reject path traversal in new name
            if "/" in name or "\\" in name or ".." in name:
                self.status_lbl.set_text(_("Failed to create folder: invalid characters in name"))
                return
            p = Path(dest_dir) / name
            if p.resolve().parent != Path(dest_dir).resolve():
                self.status_lbl.set_text(
                    _("Failed to create folder: name escapes target directory")
                )
                return
            try:
                p.mkdir(parents=True, exist_ok=False)
                self.status_lbl.set_text(f"Created folder: {name}")
                self.refresh_list()
            except Exception as e:
                self.status_lbl.set_text(f"Failed to create folder: {e}")

        self.prompt_text_dialog("New Folder", "Enter folder name:", "Untitled Folder", do_create)

    def create_new_file_dialog(self):
        dest_dir = self.current_dir or str(Path.home())

        def do_create(name):
            if not name:
                return
            # Reject path traversal in new name
            if "/" in name or "\\" in name or ".." in name:
                self.status_lbl.set_text(_("Failed to create file: invalid characters in name"))
                return
            p = Path(dest_dir) / name
            if p.resolve().parent != Path(dest_dir).resolve():
                self.status_lbl.set_text(_("Failed to create file: name escapes target directory"))
                return
            try:
                p.touch(exist_ok=False)
                self.status_lbl.set_text(f"Created file: {name}")
                self.refresh_list()
            except Exception as e:
                self.status_lbl.set_text(f"Failed to create file: {e}")

        self.prompt_text_dialog("New File", "Enter file name:", "untitled.txt", do_create)

    def show_properties(self, file_info):
        transient = (
            self.get_root()
            if hasattr(self, "get_root") and hasattr(self.get_root(), "present")
            else None
        )
        dialog = Gtk.Dialog(title="Properties", transient_for=transient, modal=True)
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)

        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(16)
        box.set_margin_bottom(16)
        box.set_margin_start(16)
        box.set_margin_end(16)

        grid = Gtk.Grid()
        grid.set_column_spacing(12)
        grid.set_row_spacing(10)

        rows = [
            ("Name:", file_info["file_name"]),
            (
                "Type:",
                file_info.get("file_type", "Folder" if file_info.get("is_dir") else "Unknown"),
            ),
            ("Location:", file_info["file_path"]),
            (
                "Size:",
                format_size(file_info["file_size"])
                if file_info["file_size"] is not None
                else "Folder",
            ),
            ("Modified:", format_timestamp(file_info["last_modified"])),
        ]

        try:
            p = Path(file_info["file_path"])
            mode = p.stat().st_mode
            perms = stat.filemode(mode)
            rows.append(("Permissions:", perms))
        except Exception:
            pass

        for i, (label, val) in enumerate(rows):
            lbl_title = Gtk.Label(label=label)
            lbl_title.set_halign(Gtk.Align.START)
            lbl_title.get_style_context().add_class("file-name-label")

            lbl_val = Gtk.Label(label=val)
            lbl_val.set_halign(Gtk.Align.START)
            lbl_val.set_selectable(True)
            lbl_val.set_wrap(True)
            lbl_val.set_max_width_chars(40)

            grid.attach(lbl_title, 0, i, 1, 1)
            grid.attach(lbl_val, 1, i, 1, 1)

        box.append(grid)
        dialog.connect("response", lambda dlg, resp: dialog.destroy())
        dialog.present()


def list_directory_contents(dir_path, indexer):
    """Utility function to list both folders and database files inside a directory."""
    import sqlite3

    items = []
    try:
        path_obj = Path(dir_path).expanduser().resolve()
        if not path_obj.exists() or not path_obj.is_dir():
            return []

        # Select all indexed files residing under this folder
        conn = sqlite3.connect(indexer.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            # Escape LIKE wildcards in path to prevent SQL injection
            escaped_path = (
                str(path_obj).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            cursor.execute(
                """
                SELECT id, file_path, file_name, file_type, file_size, last_modified, content_summary
                FROM files
                WHERE file_path LIKE ? ESCAPE '\\'
            """,
                (f"{escaped_path}/%",),
            )
            db_files = {row["file_path"]: dict(row) for row in cursor.fetchall()}
        finally:
            conn.close()

        for entry in path_obj.iterdir():
            if entry.name.startswith("."):
                continue

            entry_str = str(entry)
            try:
                file_stat = entry.stat()
                mtime = file_stat.st_mtime
            except Exception:
                continue

            if entry.is_dir():
                items.append(
                    {
                        "is_dir": True,
                        "file_path": entry_str,
                        "file_name": entry.name,
                        "file_type": "Folder",
                        "file_size": None,
                        "last_modified": mtime,
                        "content_summary": "",
                        "similarity": 0.0,
                    }
                )
            else:
                db_rec = db_files.get(entry_str)
                if db_rec:
                    items.append(
                        {
                            "is_dir": False,
                            "file_path": entry_str,
                            "file_name": entry.name,
                            "file_type": db_rec["file_type"],
                            "file_size": db_rec["file_size"],
                            "last_modified": db_rec["last_modified"],
                            "content_summary": db_rec["content_summary"],
                            "similarity": 0.0,
                        }
                    )
                else:
                    items.append(
                        {
                            "is_dir": False,
                            "file_path": entry_str,
                            "file_name": entry.name,
                            "file_type": entry.suffix.lower().lstrip("."),
                            "file_size": file_stat.st_size,
                            "last_modified": mtime,
                            "content_summary": "File is not yet indexed (Sync Index)",
                            "similarity": 0.0,
                        }
                    )
    except Exception as e:
        from axon_logger import configure_app_logger

        logger = configure_app_logger(__name__)
        logger.exception("Error listing folder contents: %s", e)

    dirs = [x for x in items if x["is_dir"]]
    files = [x for x in items if not x["is_dir"]]
    dirs.sort(key=lambda x: x["file_name"].lower())
    files.sort(key=lambda x: x["file_name"].lower())
    return dirs + files
