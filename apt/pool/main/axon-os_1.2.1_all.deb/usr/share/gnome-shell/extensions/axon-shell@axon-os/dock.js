/**
 * Axon OS — Windows 10/11-style Taskbar
 * dock.js
 *
 * Transforms the floating dock into a full-width taskbar at the bottom.
 * Shows:
 *   - Start button linking to StartMenuPopup
 *   - Search button linking to IntentBar
 *   - Center-aligned app icons row (pinned and running) with underline active indicator
 *   - Right-aligned tray with native clock/calendar and Quick Settings (status menu)
 *   - Struts registration to prevent windows overlapping it
 *
 * GNOME Shell 45+ / GJS ESM
 */

import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Shell from 'gi://Shell';
import Meta from 'gi://Meta';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import Graphene from 'gi://Graphene';

import * as AppFavorites from 'resource:///org/gnome/shell/ui/appFavorites.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {confirmAndRun, launchAppById} from './ai-actions.js';
import StartMenuPopup from './startmenu.js';
import {SpaceStrip} from './spaces.js';
import {
    MOTION,
    PRESS_SCALE,
    _t,
    motionDuration,
    taskbarApps,
    taskbarGeometry,
    tooltipDelay,
    useMaterial,
} from './ui-logic.js';

// Animation length; 0 when the user turned animations off (reduced motion)
const motion = ms => motionDuration(ms, St.Settings.get().enable_animations);

// ─── D-Bus interfaces ─────────────────────────────────────────────────────────

const BrainInterface = `
<node>
  <interface name="org.axonos.Brain">
    <method name="ClassifyIntent">
      <arg type="s" name="text" direction="in"/>
      <arg type="s" name="response" direction="out"/>
    </method>
    <method name="Generate">
      <arg type="s" name="prompt" direction="in"/>
      <arg type="s" name="context" direction="in"/>
      <arg type="s" name="model" direction="in"/>
      <arg type="b" name="stream" direction="in"/>
      <arg type="s" name="response" direction="out"/>
    </method>
  </interface>
</node>
`;

const ContextInterface = `
<node>
  <interface name="org.axonos.Context">
    <method name="GetContextString">
      <arg type="s" name="context_string" direction="out"/>
    </method>
  </interface>
</node>
`;

const BrainProxy = Gio.DBusProxy.makeProxyWrapper(BrainInterface);
const ContextProxy = Gio.DBusProxy.makeProxyWrapper(ContextInterface);

// ─── Constants ─────────────────────────────────────────────────────────────────

const TASKBAR_HEIGHT     = 48;   // px, the visible bar
const TASKBAR_INSET      = 8;    // px it floats above and inside the screen edges
const ICON_SIZE          = 32;   // px, app icons in the taskbar
const SYMBOLIC_SIZE      = 20;   // px, the start and search glyphs
const LAUNCH_LIFT        = 1.08; // launch feedback: a gentle lift, no bounce

// When the last dock tooltip closed, so neighbours open without a delay
let lastTooltipHidden = null;

// ─── DockIcon ──────────────────────────────────────────────────────────────────

const DockIcon = GObject.registerClass(
class DockIcon extends St.Button {
    _init(opts) {
        super._init({
            style_class: 'axon-dock-icon',
            reactive: true,
            track_hover: true,
            can_focus: true,
            accessible_name: opts.label ?? '',
            // Scale from the centre, not the top-left corner
            pivot_point: new Graphene.Point({x: 0.5, y: 0.5}),
        });

        this._app      = opts.app      ?? null;
        this._label    = opts.label    ?? '';
        this._callback = opts.callback ?? (() => {});
        this._dockManager = opts.dockManager ?? null;
        this._tooltipId = null;
        this._tooltip   = null;

        // Icon Image
        let iconWidget;
        if (this._app) {
            iconWidget = this._app.create_icon_texture(ICON_SIZE);
        } else if (opts.icon) {
            // Symbolic glyphs (start, search) sit at text size, not app-icon size
            iconWidget = new St.Icon({
                gicon:     opts.icon,
                icon_size: SYMBOLIC_SIZE,
                style_class: 'axon-taskbar-icon-svg',
            });
        } else {
            iconWidget = new St.Icon({
                icon_name: 'application-x-executable-symbolic',
                icon_size: ICON_SIZE,
            });
        }

        // Active/Running Indicator (Underline bar instead of dot)
        this._dot = new St.Widget({
            style_class: 'axon-dock-dot',
            visible: this._app !== null,
        });

        // Column cell layout: icon stacked above underline dot
        const cell = new St.BoxLayout({
            vertical:     true,
            x_align:      Clutter.ActorAlign.CENTER,
            y_align:      Clutter.ActorAlign.CENTER,
            x_expand:     true,
            y_expand:     true,
        });
        cell.add_child(iconWidget);
        cell.add_child(this._dot);
        this.set_child(cell);

        this.connect('clicked',      this._onClick.bind(this));
        // Feedback on press, not on release
        this.connect('notify::pressed', this._onPressedChanged.bind(this));
        this.connect('notify::hover', this._onHoverChanged.bind(this));
        this.connect('destroy',      this._onDestroy.bind(this));

        this.connect('button-press-event', (actor, event) => {
            let button = event.get_button();
            if (button === 3) { // Right click
                if (this._dockManager) {
                    this._dockManager.showIconContextMenu(this, event);
                }
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
    }

    setRunning(running) {
        this._dot.visible = running;
    }

    bounce() {
        // Decorative only: skip it entirely when animations are off
        if (!St.Settings.get().enable_animations)
            return;
        this.ease({
            scale_y:  LAUNCH_LIFT,
            scale_x:  LAUNCH_LIFT,
            duration: motion(MOTION.enter),
            mode:     Clutter.AnimationMode.EASE_OUT_QUINT,
            onComplete: () => {
                this.ease({
                    scale_y:  1.0,
                    scale_x:  1.0,
                    duration: motion(MOTION.settle),
                    mode:     Clutter.AnimationMode.EASE_OUT_QUINT,
                });
            },
        });
    }

    _onPressedChanged() {
        // Starts from the current scale, so a quick tap can reverse mid-way
        const scale = this.pressed ? PRESS_SCALE : 1.0;
        this.ease({
            scale_x:  scale,
            scale_y:  scale,
            duration: motion(this.pressed ? MOTION.press : MOTION.release),
            mode:     Clutter.AnimationMode.EASE_OUT_QUINT,
        });
    }

    _onClick() {
        this._callback();
    }

    _onHoverChanged() {
        if (this.hover) {
            const delay = tooltipDelay(GLib.get_monotonic_time() / 1000, lastTooltipHidden);
            this._tooltipInstant = delay === 0;
            this._tooltipId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
                this._showTooltip();
                this._tooltipId = null;
                return GLib.SOURCE_REMOVE;
            });
        } else {
            if (this._tooltipId) {
                GLib.source_remove(this._tooltipId);
                this._tooltipId = null;
            }
            this._hideTooltip();
        }
    }

    _showTooltip() {
        if (this._tooltip) return;
        if (!this._label) return;

        this._tooltip = new St.Label({
            style_class: 'axon-dock-tooltip',
            text:        this._label,
        });
        Main.uiGroup.add_child(this._tooltip);

        const [iconX, iconY] = this.get_transformed_position();
        const [, natW]       = this._tooltip.get_preferred_width(-1);
        const [, natH]       = this._tooltip.get_preferred_height(-1);
        const x = Math.round(iconX + (this.width - natW) / 2);
        const y = Math.round(iconY - natH - 6);

        this._tooltip.set_position(x, y);
        if (this._tooltipInstant)
            return;
        this._tooltip.set_opacity(0);
        this._tooltip.ease({
            opacity:  255,
            duration: motion(MOTION.tooltip),
            mode:     Clutter.AnimationMode.EASE_OUT_QUINT,
        });
    }

    _hideTooltip() {
        if (!this._tooltip) return;
        const t = this._tooltip;
        this._tooltip = null;
        lastTooltipHidden = GLib.get_monotonic_time() / 1000;
        t.ease({
            opacity:    0,
            duration:   motion(MOTION.exit),
            mode:       Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => t.destroy(),
        });
    }

    _onDestroy() {
        if (this._tooltipId) {
            GLib.source_remove(this._tooltipId);
            this._tooltipId = null;
        }
        this._hideTooltip();
    }
});

// ─── DockManager / TaskbarManager ──────────────────────────────────────────────

export default class DockManager {
    constructor(extension, intentBar) {
        this._extension  = extension;
        this._intentBar  = intentBar;

        this._actor         = null;
        this._iconRow       = null;
        this._iconMap       = new Map();  // Shell.App → DockIcon
        this._visible       = false;

        this._appSystem          = Shell.AppSystem.get_default();
        this._appsChangedId      = null;
        this._windowCreatedId    = null;

        this._contextMenu        = null;
        this._clickDismissId     = null;
        this._brainProxy         = null;
        this._contextProxy       = null;

        this._startMenuPopup     = null;
    }

    enable() {
        // Async init: synchronous proxy constructors block the compositor
        // while D-Bus activation starts the Python services.
        new BrainProxy(
            Gio.DBus.session,
            'org.axonos.Brain',
            '/org/axonos/Brain',
            (proxy, error) => {
                if (error) {
                    console.warn('AxonTaskbar: could not create BrainProxy:', error.message);
                    return;
                }
                this._brainProxy = proxy;
            }
        );

        new ContextProxy(
            Gio.DBus.session,
            'org.axonos.Context',
            '/org/axonos/Context',
            (proxy, error) => {
                if (error) {
                    console.warn('AxonTaskbar: could not create ContextProxy:', error.message);
                    return;
                }
                this._contextProxy = proxy;
            }
        );

        // Create Start Menu popup instance
        this._startMenuPopup = new StartMenuPopup(
            this._extension,
            this._extension._spacesManager,
            this._intentBar
        );

        this._buildUI();
        this._populate();
        this._show();
        this._connectSignals();

        // Reposition whenever workspace or layout changes
        this._monitorsChangedId = Main.layoutManager.connect(
            'monitors-changed',
            this._reposition.bind(this)
        );
    }

    disable() {
        this._disconnectSignals();
        this.closeActiveMenu();

        if (this._monitorsChangedId) {
            Main.layoutManager.disconnect(this._monitorsChangedId);
            this._monitorsChangedId = null;
        }

        // Restore native GNOME panel items into their original parents
        // (their statusArea container bins), not directly into panel boxes.
        const quickSettings = this._actor ? this._actor._quickSettingsHolder : null;
        if (quickSettings && Main.panel) {
            const qsParent = quickSettings.get_parent();
            if (qsParent) qsParent.remove_child(quickSettings);
            const qsHome = this._quickSettingsOrigParent || Main.panel._rightBox;
            qsHome.add_child(quickSettings);
            quickSettings.x_expand = this._quickSettingsExpand ?? quickSettings.x_expand;
            this._quickSettingsOrigParent = null;
        }
        const dateMenu = this._actor ? this._actor._dateMenuHolder : null;
        if (dateMenu && Main.panel) {
            const dmParent = dateMenu.get_parent();
            if (dmParent) dmParent.remove_child(dateMenu);
            const dmHome = this._dateMenuOrigParent || Main.panel._centerBox;
            dmHome.add_child(dateMenu);
            dateMenu.x_expand = this._dateMenuExpand ?? dateMenu.x_expand;
            this._dateMenuOrigParent = null;
        }

        if (this._spaceStrip) {
            this._spaceStrip.destroy();
            this._spaceStrip = null;
        }

        for (const [settings, id] of this._materialIds ?? [])
            settings.disconnect(id);
        this._materialIds = null;
        this._settings = null;
        this._a11ySettings = null;
        this._bar = null;

        if (this._actor) {
            Main.layoutManager.removeChrome(this._actor);
            this._actor.destroy();
            this._actor = null;
        }

        if (this._startMenuPopup) {
            this._startMenuPopup.destroy();
            this._startMenuPopup = null;
        }

        this._iconRow  = null;
        this._iconMap.clear();
        this._visible    = false;
        this._brainProxy = null;
        this._contextProxy = null;
    }

    _buildUI() {
        // The chrome actor sits on the bottom edge so GNOME reserves its
        // strut; the visible bar floats inside it (see taskbarGeometry).
        this._actor = new St.Bin({
            style_class: 'axon-taskbar-frame',
            x_expand: true,
        });
        const bar = new St.BoxLayout({
            style_class: 'axon-taskbar',
            vertical:    false,
            reactive:    true,
            track_hover: true,
            x_expand:    true,
            y_expand:    true,
        });
        this._actor.set_child(bar);
        this._bar = bar;

        // 1. Left container: Start button and Search/Intent icon
        const leftBox = new St.BoxLayout({
            style_class: 'axon-taskbar-left',
            vertical: false,
            y_align: Clutter.ActorAlign.CENTER,
        });
        bar.add_child(leftBox);

        // Start Menu button
        const startBtn = new DockIcon({
            icon: Gio.ThemedIcon.new('axon-os-symbolic'),
            label: _t('Start Menu'),
            callback: () => this._startMenuPopup && this._startMenuPopup.toggle(),
            dockManager: this,
        });
        leftBox.add_child(startBtn);

        // Intent Bar toggle search button
        const searchBtn = new DockIcon({
            icon: Gio.ThemedIcon.new('system-search-symbolic'),
            label: _t('Intent Bar (Search / AI)'),
            callback: () => this._intentBar && this._intentBar.toggle(),
            dockManager: this,
        });
        leftBox.add_child(searchBtn);

        // Numbered Space chips (Super+1…9), with window counts
        if (this._extension._spacesManager) {
            this._spaceStrip = new SpaceStrip(this._extension._spacesManager);
            leftBox.add_child(this._spaceStrip.actor);
        }

        // Spacer to push apps to center
        const centerSpacerLeft = new St.Widget({ x_expand: true });
        bar.add_child(centerSpacerLeft);

        // 2. Center container: App icons (pinned and running)
        this._iconRow = new St.BoxLayout({
            style_class: 'axon-taskbar-center-apps',
            vertical: false,
            y_align:  Clutter.ActorAlign.CENTER,
        });
        bar.add_child(this._iconRow);

        // Spacer to push tray to far right
        const centerSpacerRight = new St.Widget({ x_expand: true });
        bar.add_child(centerSpacerRight);

        // 3. Right container: Clock + System Indicators (stealing native items)
        const rightBox = new St.BoxLayout({
            style_class: 'axon-taskbar-right',
            vertical: false,
            y_align: Clutter.ActorAlign.CENTER,
        });
        bar.add_child(rightBox);

        // The clock is GNOME's own date menu, adopted below: it follows the
        // 12/24-hour setting and holds the calendar and notifications.

        // Migrate native Quick Settings (network/volume/power aggregate).
        // Remember the original parent so disable() can restore the exact
        // panel structure (statusArea items live inside a container bin —
        // re-adding them elsewhere corrupts the panel across lock/unlock).
        const nativeQS = Main.panel.statusArea['quickSettings'];
        if (nativeQS) {
            const parent = nativeQS.get_parent();
            if (parent) parent.remove_child(nativeQS);
            rightBox.add_child(nativeQS);
            // In the top panel it stretches; in the taskbar it hugs its icons
            this._quickSettingsExpand = nativeQS.x_expand;
            nativeQS.x_expand = false;
            this._actor._quickSettingsHolder = nativeQS;
            this._quickSettingsOrigParent = parent;
        }

        // Migrate native Clock/Calendar menu button (holds notifications)
        const nativeDate = Main.panel.statusArea['dateMenu'];
        if (nativeDate) {
            const parent = nativeDate.get_parent();
            if (parent) parent.remove_child(nativeDate);
            rightBox.add_child(nativeDate);
            this._dateMenuExpand = nativeDate.x_expand;
            nativeDate.x_expand = false;
            this._actor._dateMenuHolder = nativeDate;
            this._dateMenuOrigParent = parent;
        }

        // Show Desktop strip at the far right edge (Windows Aero Peek)
        const showDesktopBtn = new St.Button({
            style_class: 'axon-taskbar-showdesktop',
            reactive: true,
            track_hover: true,
            can_focus: true,
            accessible_name: _t('Show Desktop'),
        });
        showDesktopBtn.connect('clicked', () => this._toggleShowDesktop());
        bar.add_child(showDesktopBtn);

        // Register with Chrome Manager so windows respect taskbar boundary
        // Struts follow the actor's geometry; trackFullscreen hides it over
        // fullscreen windows (GNOME 46 has no "trackPosition" option)
        Main.layoutManager.addChrome(this._actor, {
            affectsStruts: true,
            trackFullscreen: true,
        });

        // Translucent material unless Reduce Transparency or High Contrast is on
        this._settings = this._extension.getSettings();
        this._a11ySettings = new Gio.Settings({schema_id: 'org.gnome.desktop.a11y.interface'});
        this._materialIds = [
            [this._settings, this._settings.connect('changed::reduce-transparency', () => this._updateMaterial())],
            [this._a11ySettings, this._a11ySettings.connect('changed::high-contrast', () => this._updateMaterial())],
        ];
        this._updateMaterial();

        this._reposition();
    }

    _updateMaterial() {
        if (!this._bar)
            return;
        const material = useMaterial(
            this._settings.get_boolean('reduce-transparency'),
            this._a11ySettings.get_boolean('high-contrast'));
        if (material)
            this._bar.remove_style_class_name('axon-taskbar-solid');
        else
            this._bar.add_style_class_name('axon-taskbar-solid');
    }

    _populate() {
        for (const [, icon] of this._iconMap) {
            icon.destroy();
        }
        this._iconMap.clear();

        // Pinned apps (GNOME favourites) first, then the other running apps
        const pinned = AppFavorites.getAppFavorites().getFavorites();
        const running = this._appSystem.get_running().filter(app => !this._hidden(app));
        const byId = new Map([...pinned, ...running].map(app => [app.get_id(), app]));
        for (const entry of taskbarApps(pinned.map(app => app.get_id()), running.map(app => app.get_id())))
            this._addApp(byId.get(entry.id), entry.running);
    }

    // The live-session installer only shows when it is pinned
    _hidden(app) {
        return app.get_name() === 'Axon OS Installer' &&
            !AppFavorites.getAppFavorites().isFavorite(app.get_id());
    }

    _addApp(app, running = true) {
        const existing = this._iconMap.get(app);
        if (existing) {
            existing.setRunning(running);
            return;
        }
        if (this._hidden(app)) return;

        const dockIcon = new DockIcon({
            app:      app,
            label:    app.get_name(),
            callback: () => this._activateApp(app),
            dockManager: this,
        });
        dockIcon.setRunning(running);
        this._iconRow.add_child(dockIcon);
        this._iconMap.set(app, dockIcon);
    }

    _removeApp(app) {
        const icon = this._iconMap.get(app);
        if (!icon) return;
        icon.destroy();
        this._iconMap.delete(app);
    }

    _activateApp(app) {
        const windows = app.get_windows();
        if (windows.length > 0) {
            // Windows-style taskbar behavior: clicking the focused app
            // minimizes it; clicking an unfocused app raises it.
            const focused = windows.some(w => w.has_focus());
            if (focused) {
                windows.forEach(w => w.minimize());
            } else {
                app.activate();
            }
        } else {
            app.open_new_window(-1);
        }
    }

    _toggleShowDesktop() {
        const workspace = global.workspace_manager.get_active_workspace();
        if (this._showDesktopRestore && this._showDesktopRestore.length > 0) {
            for (const w of this._showDesktopRestore) {
                try {
                    w.unminimize();
                } catch {
                    // window was closed while the desktop was shown
                }
            }
            this._showDesktopRestore = null;
        } else {
            const windows = workspace
                .list_windows()
                .filter(w => !w.skip_taskbar && !w.minimized);
            windows.forEach(w => w.minimize());
            this._showDesktopRestore = windows;
        }
    }

    _connectSignals() {
        this._appsChangedId = this._appSystem.connect(
            'app-state-changed',
            this._onAppStateChanged.bind(this)
        );

        this._windowCreatedId = global.display.connect(
            'window-created',
            this._onWindowCreated.bind(this)
        );

        this._favoritesChangedId = AppFavorites.getAppFavorites().connect(
            'changed', () => this._populate());
    }

    _disconnectSignals() {
        if (this._appsChangedId) {
            this._appSystem.disconnect(this._appsChangedId);
            this._appsChangedId = null;
        }
        if (this._windowCreatedId) {
            global.display.disconnect(this._windowCreatedId);
            this._windowCreatedId = null;
        }
        if (this._favoritesChangedId) {
            AppFavorites.getAppFavorites().disconnect(this._favoritesChangedId);
            this._favoritesChangedId = null;
        }
    }

    _onAppStateChanged(appSystem, app) {
        const state = app.get_state();
        if (state === Shell.AppState.RUNNING) {
            this._addApp(app);
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                const icon = this._iconMap.get(app);
                if (icon) icon.bounce();
                return GLib.SOURCE_REMOVE;
            });
        } else if (state === Shell.AppState.STOPPED) {
            // A pinned app stays, without its running dot
            if (AppFavorites.getAppFavorites().isFavorite(app.get_id()))
                this._iconMap.get(app)?.setRunning(false);
            else
                this._removeApp(app);
        }
    }

    _onWindowCreated(_display, window) {
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, () => {
            const tracker = Shell.WindowTracker.get_default();
            const app     = tracker.get_window_app(window);
            if (app) {
                const icon = this._iconMap.get(app);
                if (icon) icon.bounce();
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    _reposition() {
        if (!this._actor) return;

        const monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return;

        const geo = taskbarGeometry(monitor, TASKBAR_HEIGHT, TASKBAR_INSET);
        this._actor.set_position(geo.x, geo.y);
        this._actor.set_size(geo.width, geo.height);
        this._actor.set_style(`padding: 0 ${geo.inset}px ${geo.inset}px ${geo.inset}px;`);
    }

    _show() {
        if (!this._actor) return;
        this._visible = true;
        this._reposition();
        this._actor.show();
    }

    _hide() {
        if (!this._actor) return;
        this._visible = false;
        this._actor.hide();
    }

    toggle() {
        if (this._visible) {
            this._hide();
        } else {
            this._show();
        }
    }

    showIconContextMenu(icon, event) {
        this.closeActiveMenu();

        this._contextMenu = new St.BoxLayout({
            style_class: 'axon-dock-menu',
            vertical:    true,
            reactive:    true,
            accessible_name: _t('{app} menu', {app: icon._label || _t('Application')}),
        });
        // Keyboard: Up/Down move between items, Escape closes
        this._contextMenu.connect('key-press-event', (_actor, ev) => {
            const key = ev.get_key_symbol();
            if (key === Clutter.KEY_Escape) {
                this.closeActiveMenu();
                icon.grab_key_focus();
                return Clutter.EVENT_STOP;
            }
            if (key === Clutter.KEY_Up || key === Clutter.KEY_Down) {
                const items = this._contextMenu.get_children()
                    .filter(c => c instanceof St.Button && c.reactive);
                const at = items.findIndex(c => c.has_key_focus());
                const next = key === Clutter.KEY_Up ? at - 1 : at + 1;
                items[(next + items.length) % items.length]?.grab_key_focus();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        const titleLabel = new St.Label({
            style_class: 'axon-dock-menu-title',
            text: icon._label || _t('Application'),
        });
        this._contextMenu.add_child(titleLabel);

        if (icon._app) {
            const favorites = AppFavorites.getAppFavorites();
            const appId = icon._app.get_id();
            const pinned = favorites.isFavorite(appId);
            const pinBtn = new St.Button({
                style_class: 'axon-dock-menu-item',
                label: pinned ? _t('Unpin from Taskbar') : _t('Pin to Taskbar'),
                x_align: Clutter.ActorAlign.START,
                reactive: true,
                can_focus: true,
            });
            pinBtn.connect('clicked', () => {
                this.closeActiveMenu();
                if (pinned)
                    favorites.removeFavorite(appId);
                else
                    favorites.addFavorite(appId);
            });
            this._contextMenu.add_child(pinBtn);

            if (icon._app.get_n_windows() > 0) {
                const closeBtn = new St.Button({
                    style_class: 'axon-dock-menu-item',
                    label: _t('Quit'),
                    x_align: Clutter.ActorAlign.START,
                    reactive: true,
                    can_focus: true,
                });
                closeBtn.connect('clicked', () => {
                    icon._app.request_quit();
                    this.closeActiveMenu();
                });
                this._contextMenu.add_child(closeBtn);
            }

            const sep = new St.Widget({ style_class: 'axon-dock-separator', style: 'height: 1px; width: 90%;' });
            this._contextMenu.add_child(sep);
        }

        const loadingItem = new St.Button({
            style_class: 'axon-dock-menu-item axon-dock-menu-status',
            label: _t('Loading AI shortcuts…'),
            x_align: Clutter.ActorAlign.START,
            reactive: false,
        });
        this._contextMenu.add_child(loadingItem);

        Main.uiGroup.add_child(this._contextMenu);
        this._repositionMenu(icon);
        // Put keyboard focus in the menu so it can be used without a mouse
        const firstItem = this._contextMenu.get_children().find(c => c instanceof St.Button && c.reactive);
        (firstItem ?? this._contextMenu).grab_key_focus();

        let contextStr = 'Active workspace.';
        if (this._contextProxy) {
            try {
                this._contextProxy.GetContextStringRemote((c, err) => {
                    if (!err && c) {
                        contextStr = c[0] || c;
                    }
                    this._requestAIPredictedActions(icon, contextStr, loadingItem);
                });
            } catch (e) {
                this._requestAIPredictedActions(icon, contextStr, loadingItem);
            }
        } else {
            this._requestAIPredictedActions(icon, contextStr, loadingItem);
        }

        this._clickDismissId = global.stage.connect('button-press-event', (actor, event) => {
            this.closeActiveMenu();
            return Clutter.EVENT_PROPAGATE;
        });
    }

    _requestAIPredictedActions(icon, contextStr, loadingItem) {
        if (!this._brainProxy) {
            if (loadingItem) loadingItem.set_label(_t('AI Brain service offline'));
            return;
        }

        let appName = icon._label || 'this application';
        let prompt = `Given the user is working on the desktop and the current context is:\n"${contextStr}"\nGenerate 2-3 short, context-specific action/task shortcuts for the application "${appName}" (e.g. "Resume my report" for LibreOffice, "Run tests" for Terminal, "Open inbox" for Mail). Reply ONLY as a JSON array of strings, e.g. ["Action 1", "Action 2"]. Do not include markdown, code blocks, or explanations.`;

        this._brainProxy.GenerateRemote(prompt, "", "", false, (result, error) => {
            if (!this._contextMenu) return;

            if (!error && result) {
                try {
                    let [response] = result;
                    let cleanResponse = response.trim();
                    if (cleanResponse.startsWith('```')) {
                        cleanResponse = cleanResponse.replace(/^```json|```$/g, '').trim();
                    }
                    if (cleanResponse.startsWith('`')) {
                        cleanResponse = cleanResponse.replace(/^`|`$/g, '').trim();
                    }
                    let actions = JSON.parse(cleanResponse);
                    if (Array.isArray(actions) && actions.length > 0) {
                        this._contextMenu.remove_child(loadingItem);

                        actions.slice(0, 3).forEach(act => {
                            const btn = new St.Button({
                                style_class: 'axon-dock-menu-item',
                                label: '⬡ ' + act,
                                x_align: Clutter.ActorAlign.START,
                                reactive: true,
                                can_focus: true,
                            });
                            btn.connect('clicked', () => {
                                this._executeAIAction(act, icon);
                                this.closeActiveMenu();
                            });
                            this._contextMenu.add_child(btn);
                        });
                        this._repositionMenu(icon);
                    } else {
                        if (loadingItem) loadingItem.set_label(_t('No shortcuts suggested'));
                    }
                } catch (e) {
                    if (loadingItem) loadingItem.set_label(_t('No shortcuts suggested'));
                }
            } else {
                if (loadingItem) loadingItem.set_label(_t('AI suggestion failed'));
            }
        });
    }

    _executeAIAction(actionText, icon) {
        if (!this._brainProxy) return;

        this._brainProxy.ClassifyIntentRemote(actionText, (result, error) => {
            if (!error && result) {
                try {
                    let [response] = result;
                    let action = JSON.parse(response);
                    if (action && action.action === 'run_command' && action.command) {
                        confirmAndRun(action.command);
                    } else if (action && action.action === 'open_app' && action.app) {
                        launchAppById(String(action.app));
                    } else {
                        if (icon._app) {
                            icon._app.activate();
                        }
                    }
                } catch (e) {
                    if (icon._app) icon._app.activate();
                }
            }
        });
    }

    _repositionMenu(icon) {
        if (!this._contextMenu) return;

        const [iconX, iconY] = icon.get_transformed_position();
        const [, natW] = this._contextMenu.get_preferred_width(-1);
        const [, natH] = this._contextMenu.get_preferred_height(-1);

        const x = Math.round(iconX + (icon.width - natW) / 2);
        const y = Math.round(iconY - natH - 8);

        this._contextMenu.set_position(x, y);
    }

    closeActiveMenu() {
        if (this._clickDismissId) {
            global.stage.disconnect(this._clickDismissId);
            this._clickDismissId = null;
        }
        if (this._contextMenu) {
            this._contextMenu.destroy();
            this._contextMenu = null;
        }
    }
}
