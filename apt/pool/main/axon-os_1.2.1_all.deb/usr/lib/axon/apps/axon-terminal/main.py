"""
main.py — Entry point for the Axon Terminal application.

A GTK4 + libadwaita AI-powered terminal emulator for Axon OS.
Features:
  • Multi-tab VTE terminal with dark Axon-branded theme
  • AI diagnosis overlay on command failures (via org.axonos.Brain)
  • Natural language command bar (Ctrl+Shift+A)
  • Smart command suggestions after errors
"""

from __future__ import annotations

import sys
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
from gi.repository import Adw, Gdk, Gtk

# Shared GTK helpers live in apps/shared next to every app
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "shared"))
from axon_gtk_utils import fit_default_size, load_app_css

# Ensure sibling modules are importable when running as a script.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from terminal_widget import TerminalWidget

# Translations (services/i18n.py); plain English when services/ isn't found
for _base in (*Path(__file__).resolve().parents, Path("/usr/lib/axon")):
    if (_base / "services" / "i18n.py").is_file():
        sys.path.insert(0, str(_base / "services"))
        break
try:
    from i18n import _
except ImportError:

    def _(text: str) -> str:  # type: ignore[no-redef]
        return text


class AxonTerminalWindow(Adw.ApplicationWindow):
    """Main window for Axon Terminal."""

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)

        self.set_title(_("Axon Terminal"))
        fit_default_size(self, 900, 600)
        self.set_icon_name("axon-terminal")

        # ---- Load CSS (design tokens first, once) ---------------------------
        load_app_css(Path(__file__).resolve().parent / "main.css")

        # ---- Root layout ---------------------------------------------------
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_content(root)

        # ---- Header bar ----------------------------------------------------
        header = Adw.HeaderBar()
        header.add_css_class("header-bar")

        # New tab button
        new_tab_btn = Gtk.Button(icon_name="tab-new-symbolic")
        new_tab_btn.set_tooltip_text(_("New tab (Ctrl+Shift+T)"))
        new_tab_btn.update_property([Gtk.AccessibleProperty.LABEL], ["New tab"])
        new_tab_btn.connect("clicked", self._on_new_tab)
        header.pack_start(new_tab_btn)

        # AI bar toggle button
        ai_btn = Gtk.Button(label=_("⬡ AI"))
        ai_btn.add_css_class("ai-toggle-btn")
        ai_btn.set_tooltip_text(_("Toggle AI command bar (Ctrl+Shift+A)"))
        ai_btn.connect("clicked", self._on_ai_toggle)
        header.pack_end(ai_btn)

        root.append(header)

        # ---- Terminal widget -----------------------------------------------
        self._terminal_widget = TerminalWidget()
        self._terminal_widget.set_vexpand(True)
        root.append(self._terminal_widget)

        # ---- Keyboard shortcuts --------------------------------------------
        # Capture phase: a focused Vte.Terminal consumes every key press, so a
        # bubble-phase controller on the window would never see these.
        key_ctrl = Gtk.EventControllerKey()
        key_ctrl.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        key_ctrl.connect("key-pressed", self._on_key_pressed)
        self.add_controller(key_ctrl)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _on_new_tab(self, button: Gtk.Button) -> None:
        """Open a new terminal tab."""
        self._terminal_widget.new_tab()

    def _on_ai_toggle(self, button: Gtk.Button) -> None:
        """Toggle the NL command bar."""
        self._terminal_widget.toggle_nl_bar()

    def _on_key_pressed(
        self,
        controller: Gtk.EventControllerKey,
        keyval: int,
        keycode: int,
        state: Gdk.ModifierType,
    ) -> bool:
        """Handle global keyboard shortcuts."""
        ctrl_shift = Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.SHIFT_MASK

        if (state & ctrl_shift) == ctrl_shift:
            # Ctrl+Shift+A — toggle NL command bar
            if keyval in (Gdk.KEY_a, Gdk.KEY_A):
                self._terminal_widget.toggle_nl_bar()
                return True
            # Ctrl+Shift+T — new tab
            if keyval in (Gdk.KEY_t, Gdk.KEY_T):
                self._terminal_widget.new_tab()
                return True
            # Ctrl+Shift+W — close active tab
            if keyval in (Gdk.KEY_w, Gdk.KEY_W):
                self._terminal_widget.close_active_tab()
                return True

        return False


class AxonTerminalApp(Adw.Application):
    """Axon Terminal application."""

    def __init__(self) -> None:
        super().__init__(application_id="io.github.axon_os.Terminal")
        self._window: AxonTerminalWindow | None = None

    def do_activate(self) -> None:  # type: ignore[override]
        """Create and present the main window."""
        if self._window is None:
            self._window = AxonTerminalWindow(application=self)

        self._window.present()


# Optional type hint import at module scope


def main() -> int:
    """Application entry point."""
    app = AxonTerminalApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
